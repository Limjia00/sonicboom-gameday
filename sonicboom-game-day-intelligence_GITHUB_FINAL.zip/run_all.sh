#!/usr/bin/env bash
# Rebuild everything from the saved raw extracts (data/raw). Raw KBL/KMA numbers were read from public pages, see src/browser_extraction_notes.md
set -euo pipefail
cd "$(dirname "$0")"
python src/collect_kbl.py
python src/collect_weather.py
python src/build_dataset.py
python src/validate_data.py
python src/analysis.py
python src/train_model.py
python src/build_html.py
python src/build_readme.py
python src/verify_outputs.py
