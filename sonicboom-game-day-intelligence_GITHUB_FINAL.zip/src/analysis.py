"""Step 4 - EDA. Every table reports n and an uncertainty band. Nothing here is a causal estimate.
Because season level shifts a lot (mean 1,548 -> 2,472), comparisons are also shown *within season* or
'season-adjusted' (attendance / that season's mean) so that a trend is not mistaken for a driver."""
import json
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from config import PROC, TAB, FIG, OUT, RANDOM_STATE

_available_fonts = {f.name for f in font_manager.fontManager.ttflist}
_plot_font = next((f for f in ["Noto Sans CJK KR", "NanumGothic", "AppleGothic", "Malgun Gothic", "UnDotum"] if f in _available_fonts), "DejaVu Sans")
plt.rcParams.update({"font.family": _plot_font, "axes.unicode_minus": False,
                     "axes.spines.top": False, "axes.spines.right": False, "figure.dpi": 130})
rng = np.random.default_rng(RANDOM_STATE)
df = pd.read_csv(PROC / "game_level_dataset.csv", parse_dates=["game_date"])
df["season_mean"] = df.groupby("season").attendance.transform("mean")
df["rel"] = df.attendance / df.season_mean                       # season-adjusted attendance index (1.0 = season average)
df["dow_name"] = df.day_of_week.map(dict(enumerate(["월", "화", "수", "목", "금", "토", "일"])))
DAYS = ["월", "화", "수", "목", "금", "토", "일"]

def ci_mean(x, level=0.95):
    x = np.asarray(x, float); n = len(x)
    if n < 2: return (np.nan, np.nan)
    h = stats.t.ppf((1 + level) / 2, n - 1) * x.std(ddof=1) / np.sqrt(n)
    return (x.mean() - h, x.mean() + h)
def boot_diff(a, b, n=10000):
    a, b = np.asarray(a, float), np.asarray(b, float)
    d = [rng.choice(a, len(a)).mean() - rng.choice(b, len(b)).mean() for _ in range(n)]
    return tuple(np.quantile(d, [0.025, 0.975]))
def group_table(col, order=None):
    rows = []
    for k, g in df.groupby(col):
        lo, hi = ci_mean(g.attendance)
        rows.append(dict(group=k, n=len(g), mean=g.attendance.mean(), median=g.attendance.median(), ci95_lo=lo, ci95_hi=hi,
                         season_adj_index=g.rel.mean()))
    t = pd.DataFrame(rows)
    if order: t = t.set_index("group").loc[order].reset_index()
    return t

out = {}
# 1 season
t = df.groupby("season").attendance.agg(n="count", mean="mean", median="median", sd="std", min="min", max="max").reset_index()
t["ci95_lo"], t["ci95_hi"] = zip(*[ci_mean(g.attendance) for _, g in df.groupby("season")])
t["near_capacity_games"] = df.groupby("season").near_capacity_flag.sum().values
t.to_csv(TAB / "eda_01_season.csv", index=False); out["season"] = t.to_dict("records")
kw = stats.kruskal(*[g.attendance for _, g in df.groupby("season")])
out["season_kruskal_p"] = float(kw.pvalue)

# 2 day of week
t = group_table("dow_name", DAYS); t.to_csv(TAB / "eda_02_dayofweek.csv", index=False); out["dow"] = t.to_dict("records")

# 3 day type (weekend vs weekday, + weekday holiday) overall & within season
wk = df[df.weekend_flag == 1].attendance; wd = df[df.weekend_flag == 0].attendance
lo, hi = boot_diff(wk, wd)
mw = stats.mannwhitneyu(wk, wd)
by_season = []
for s, g in df.groupby("season"):
    a = g[g.weekend_flag == 1].attendance; b = g[g.weekend_flag == 0].attendance
    by_season.append(dict(season=s, n_weekend=len(a), n_weekday=len(b), weekend_mean=a.mean(), weekday_mean=b.mean(),
                          diff=a.mean() - b.mean(), ratio=a.mean() / b.mean()))
out["weekend"] = dict(n_weekend=len(wk), n_weekday=len(wd), weekend_mean=wk.mean(), weekday_mean=wd.mean(), diff=wk.mean() - wd.mean(),
                      diff_boot95=[lo, hi], mannwhitney_p=float(mw.pvalue), by_season=by_season)
pd.DataFrame(by_season).to_csv(TAB / "eda_03_weekend_by_season.csv", index=False)
dt = group_table("day_type", ["weekday", "saturday", "sunday", "weekday_holiday"]); dt.to_csv(TAB / "eda_03_daytype.csv", index=False)
out["day_type"] = dt.to_dict("records")

# 4 opponents: raw and day-type/season-adjusted (residual after removing day-type and season means)
X = pd.get_dummies(df[["day_type", "season"]], drop_first=True).astype(float); X["c"] = 1.0
beta = np.linalg.lstsq(X.values, df.attendance.values, rcond=None)[0]
df["resid_daytype_season"] = df.attendance - X.values @ beta
rows = []
for k, g in df.groupby("opponent"):
    lo, hi = ci_mean(g.resid_daytype_season)
    rows.append(dict(opponent=k, n=len(g), mean=g.attendance.mean(), weekend_or_holiday_share=(g.off_day.mean()),
                     adj_effect=g.resid_daytype_season.mean(), adj_ci95_lo=lo, adj_ci95_hi=hi, ODI_next_season=None))
opp = pd.DataFrame(rows).sort_values("mean", ascending=False)
opp.to_csv(TAB / "eda_04_opponent.csv", index=False); out["opponent"] = opp.to_dict("records")

# 5 team performance vs attendance (raw Spearman and within day-type+season = partial)
perf = {}
for c in ["pregame_KT_win_pct", "KT_last5_win_pct", "pregame_KT_rank", "opponent_win_pct_before_game", "opponent_rank_before_game"]:
    r, p = stats.spearmanr(df[c], df.attendance)
    r2, p2 = stats.spearmanr(df[c], df.resid_daytype_season)
    bs = [stats.spearmanr(df[c].iloc[i], df.resid_daytype_season.iloc[i])[0] for i in [rng.integers(0, len(df), len(df)) for _ in range(2000)]]
    perf[c] = dict(spearman_raw=r, p_raw=p, spearman_adj=r2, p_adj=p2, adj_boot95=list(np.nanquantile(bs, [0.025, 0.975])))
out["performance"] = perf
pd.DataFrame(perf).T.to_csv(TAB / "eda_05_performance.csv")

# 6 start time - and why it cannot be separated from day type
ct = pd.crosstab(df.day_type, df.afternoon_game.map({0: "evening(17h+)", 1: "afternoon(<17h)"}))
ct.to_csv(TAB / "eda_06_time_vs_daytype.csv")
tt = df.groupby(["day_type", "afternoon_game"]).attendance.agg(["count", "mean"]).reset_index()
tt.to_csv(TAB / "eda_06_time_slot.csv", index=False)
out["time"] = dict(crosstab=ct.reset_index().to_dict("records"), table=tt.to_dict("records"),
                   afternoon_mean=df[df.afternoon_game == 1].attendance.mean(), evening_mean=df[df.afternoon_game == 0].attendance.mean())

# 7 weather
w = []
for label, sub in [("all games", df), ("weekday only", df[df.day_type == "weekday"]), ("weekend only", df[df.weekend_flag == 1])]:
    a = sub[sub.rain_flag == 1].attendance; b = sub[sub.rain_flag == 0].attendance
    lo, hi = boot_diff(a, b) if len(a) > 1 and len(b) > 1 else (np.nan, np.nan)
    w.append(dict(subset=label, n_rain=len(a), n_dry=len(b), rain_mean=a.mean(), dry_mean=b.mean(), diff=a.mean() - b.mean(), diff_boot95_lo=lo, diff_boot95_hi=hi,
                  adj_diff_after_daytype_season=sub[sub.rain_flag == 1].resid_daytype_season.mean() - sub[sub.rain_flag == 0].resid_daytype_season.mean()))
pd.DataFrame(w).to_csv(TAB / "eda_07_weather_rain.csv", index=False); out["rain"] = w
r, p = stats.spearmanr(df.temp_avg, df.resid_daytype_season)
out["temp"] = dict(spearman_adj=r, p=p)

# 8 momentum
mom = {}
d2 = df.dropna(subset=["rolling_3_home_attendance"])
for c in ["previous_home_attendance", "rolling_3_home_attendance", "rolling_5_home_attendance"]:
    d3 = df.dropna(subset=[c]); r, p = stats.spearmanr(d3[c], d3.attendance); r2, p2 = stats.spearmanr(d3[c], d3.resid_daytype_season)
    mom[c] = dict(spearman_raw=r, p_raw=p, spearman_adj=r2, p_adj=p2, n=len(d3))
out["momentum"] = mom; pd.DataFrame(mom).T.to_csv(TAB / "eda_08_momentum.csv")

# feature stability across seasons
stab = []
for s, g in df.groupby("season"):
    base = g[g.day_type == "weekday"].attendance.mean()
    stab.append(dict(season=s, weekday_mean=base, saturday_premium=g[g.day_type == "saturday"].attendance.mean() - base,
                     sunday_premium=g[g.day_type == "sunday"].attendance.mean() - base,
                     weekday_holiday_premium=g[g.day_type == "weekday_holiday"].attendance.mean() - base if (g.day_type == "weekday_holiday").any() else np.nan,
                     n_weekday_holiday=int((g.day_type == "weekday_holiday").sum())))
pd.DataFrame(stab).to_csv(TAB / "eda_09_stability_daytype.csv", index=False)
piv = df.pivot_table(index="opponent", columns="season", values="resid_daytype_season", aggfunc="mean")
sp = {f"{a} vs {b}": float(stats.spearmanr(piv[a], piv[b])[0]) for i, a in enumerate(piv.columns) for b in piv.columns[i + 1:]}
piv.round(0).to_csv(TAB / "eda_09_stability_opponent.csv")
out["stability"] = dict(daytype=stab, opponent_rank_corr=sp)

# drivers of level shifts vs. simple day-type: how much of the variance does day-type explain?
grp = df.groupby(["season", "day_type"]).attendance.transform("mean")
out["variance_explained_daytype_season"] = float(1 - ((df.attendance - grp) ** 2).sum() / ((df.attendance - df.attendance.mean()) ** 2).sum())

# game-level payload for the interactive HTML (only real values)
cols = ["game_id", "season", "game_date", "opponent", "day_type", "dow_name", "start_time", "afternoon_game", "round", "attendance", "rel",
        "pregame_KT_win_pct", "KT_last5_win_pct", "pregame_KT_rank", "opponent_rank_before_game", "rain_flag", "precip_mm", "temp_avg",
        "rolling_3_home_attendance", "near_capacity_flag", "post_result", "off_day", "public_holiday"]
pay = df[cols].copy(); pay["game_date"] = pay.game_date.dt.strftime("%Y-%m-%d")
out["games"] = json.loads(pay.round(4).to_json(orient="records", force_ascii=False))
(OUT / "eda_payload.json").write_text(json.dumps(out, ensure_ascii=False, default=float))

# ---- figures (static, for README / GitHub) ------------------------------------------------------------------
C = ["#1f3a5f", "#c8553d", "#7a8b99", "#e0a458"]
fig, ax = plt.subplots(figsize=(7, 4)); data = [g.attendance.values for _, g in df.groupby("season")]
ax.boxplot(data, tick_labels=sorted(df.season.unique()), showmeans=True); ax.set_ylabel("관중 (명)"); ax.set_title("시즌 평균 관중은 2022-23 이후 매 시즌 증가했다")
fig.tight_layout(); fig.savefig(FIG / "fig01_season.png"); plt.close(fig)
fig, ax = plt.subplots(figsize=(7, 4)); t = group_table("day_type", ["weekday", "saturday", "sunday", "weekday_holiday"])
ax.bar(["평일", "토", "일", "평일 공휴일"], t["mean"], yerr=[t["mean"] - t.ci95_lo, t.ci95_hi - t["mean"]], color=C[0], capsize=4)
for i, n in enumerate(t.n): ax.text(i, 60, f"n={n}", ha="center", color="white")
ax.set_ylabel("평균 관중 (명, 95% CI)"); ax.set_title("토·일·평일공휴일이 평일보다 크게 높다 (상관 관찰)"); fig.tight_layout(); fig.savefig(FIG / "fig02_daytype.png"); plt.close(fig)
fig, ax = plt.subplots(figsize=(7, 4.5)); o = opp.sort_values("adj_effect")
ax.barh(o.opponent, o.adj_effect, xerr=[o.adj_effect - o.adj_ci95_lo, o.adj_ci95_hi - o.adj_effect], color=C[1], capsize=3)
ax.axvline(0, color="k", lw=0.8); ax.set_xlabel("요일유형·시즌 보정 후 평균 차이 (명, 95% CI, 상대당 n=12)"); ax.set_title("상대팀별 관중 차이: 신뢰구간이 넓어 확정 순위는 아니다")
fig.tight_layout(); fig.savefig(FIG / "fig03_opponent.png"); plt.close(fig)
fig, ax = plt.subplots(figsize=(6, 4.5)); ax.scatter(df.pregame_KT_win_pct, df.resid_daytype_season, c=C[0], alpha=0.7)
ax.set_xlabel("KT 경기 전 승률(수축 추정)"); ax.set_ylabel("요일유형·시즌 보정 후 관중 잔차"); ax.set_title("팀 성적과 관중: 요일 보정 후 관계는 약하다"); fig.tight_layout(); fig.savefig(FIG / "fig04_winpct.png"); plt.close(fig)
o2 = pd.read_csv(TAB / "backtest_predictions.csv", parse_dates=["game_date"])
fig, ax = plt.subplots(figsize=(10, 4)); ax.plot(o2.game_date, o2.y, color="k", lw=1, label="실제"); ax.plot(o2.game_date, o2.pred_A, color=C[2], lw=1, label="Model A (사전)")
ax.plot(o2.game_date, o2.pred_B, color=C[1], lw=1.2, label="Model B (경기주간)"); ax.legend(); ax.set_ylabel("관중"); ax.set_title("Out-of-time 예측 vs 실제 (직전 시즌까지만 학습)"); fig.tight_layout(); fig.savefig(FIG / "fig05_actual_vs_forecast.png"); plt.close(fig)
print("EDA done. variance explained by season x day-type means:", round(out["variance_explained_daytype_season"], 3))
print(json.dumps(out["weekend"], ensure_ascii=False, default=float, indent=1)[:900])
print(pd.DataFrame(out["performance"]).T.round(3))
print(pd.DataFrame(w).round(1).to_string())
print(pd.DataFrame(mom).T.round(3))
