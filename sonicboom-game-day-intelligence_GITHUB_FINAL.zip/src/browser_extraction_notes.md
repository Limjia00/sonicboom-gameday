# How the raw KBL / KMA extracts were read (public pages, browser session, 2026-09-27)

No login, API key, download, or access-control bypass was used. The pages are JS apps, so the rendered DOM was read.

* **Schedule/results**: `https://www.kbl.or.kr/match/schedule`. Month navigation (`button[title="이전으로"]`) was
  clicked month by month from 2026-04 back to 2022-10; each `div.game-schedule-list#game-YYYYMMDD > ul > li`
  was read for: game key (`i[data-key]`, e.g. `S47G01N004`), label (정규시즌 etc.), start time, venue,
  home team + score (listed first), away team + score. Only `정규시즌` rows were kept (270 games/season).
* **Attendance**: `https://www.kbl.or.kr/record/crowd` -> "팀 관중현황" -> team + season selector; table columns:
  season / team / 경기구분 / 경기번호 / 라운드 / 경기장 / 날짜 / 관중수. Rows with 경기구분 = 정규경기 were kept.
  Extracted for 10 teams x 4 seasons; **GS 2022-23~2024-25 and SN 2023-24~2024-25 were not retrievable** (page returned no rows).
* **Final standings**: `https://www.kbl.or.kr/match/team-ranking` (used only to verify W-L of the scraped scores).
* **Weather**: `https://www.weather.go.kr/w/observation/land/past-obs/obs-by-day.do?stn=119&yy=YYYY&mm=M&obs=1`
  (monthly calendar; 수원(유) 119), parsed for the 108 game dates.
* **Cross-checks performed**: (1) calculated W-L equals the official final W-L for 40/40 team-seasons; (2) every saved attendance row's home team matches the home team of the same game number in the schedule data (945/945); (3) KT home dates in the attendance table match KT home dates in the schedule data (108/108).
* **Team-code normalization**: the four-season files use one internal code for the same comparison slot across name/relocation changes. User-facing labels avoid applying a later city/name to earlier seasons (e.g. KCC, 고양 캐롯·소노, 안양 KGC·정관장).
* **Public holidays**: statutory/substitute holidays were assembled from the official public-holiday regulation (`law.go.kr`, 법령 ID 002404). Temporary holidays in the analysis window were separately cross-checked against government notices: 2023-10-02 (인사혁신처 공고 제2023-400호 안내 via 고용복지+센터), 2024-10-01 (고용노동부 공지), 2025-01-27 (대한민국 정책브리핑), and 2026 dates against the 우주항공청 2026 월력요항. The saved snapshot is `data/raw/kr_public_holidays_2022_2026.csv`.
