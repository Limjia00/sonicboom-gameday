"""Step 2 - build the game-level dataset (1 row = 1 KT regular-season home game).

LEAKAGE RULES (enforced in code):
  * Every team-performance number is recomputed from league games with date STRICTLY BEFORE the game date
    (same-day earlier games are ignored -> conservative). Season-final rank/win% is never used.
  * Attendance-derived features use only earlier KT home games (rolling*) or earlier SEASONS (opponent draw index).
  * Post-game columns (scores, result) are kept for reference but are prefixed `post_` and excluded from models.
"""
import numpy as np
import pandas as pd
from config import RAW, PROC, SEASONS, SHRINK_K, REST_CAP, NEAR_CAPACITY_THRESHOLD, TEAM_KO

ODI_K = 3  # pseudo-games shrinking the opponent draw index toward 1.0


def day_type(d, hol_set):
    """weekday / saturday / sunday / weekday_holiday (a public holiday that falls Mon-Fri)."""
    if d.dayofweek == 5:
        return "saturday"
    if d.dayofweek == 6:
        return "sunday"
    return "weekday_holiday" if d in hol_set else "weekday"


def shrunk_pct(w, g, k=SHRINK_K):
    return (w + 0.5 * k) / (g + k)


def team_state(games_before: pd.DataFrame, team: str, game_date: pd.Timestamp):
    """Pre-game state of `team` from games strictly before `game_date` (games_before already filtered by season+date)."""
    h = games_before[games_before.home == team][["date", "start_time", "home_win"]].rename(columns={"home_win": "win"})
    a = games_before[games_before.away == team][["date", "start_time", "home_win"]]
    a = a.assign(win=1 - a["home_win"])[["date", "start_time", "win"]]
    g = pd.concat([h, a]).sort_values(["date", "start_time"])
    n = len(g)
    w = int(g.win.sum())
    last5 = g.win.tail(5)
    last10 = g.win.tail(10)
    streak = 0
    for r in g.win.iloc[::-1]:
        if streak == 0:
            streak = 1 if r == 1 else -1
        elif (r == 1 and streak > 0) or (r == 0 and streak < 0):
            streak += 1 if r == 1 else -1
        else:
            break
    rest = REST_CAP if n == 0 else min((game_date - g.date.max()).days, REST_CAP)
    home_g = games_before[games_before.home == team]
    hw = int(home_g.home_win.sum())
    return dict(games=n, wins=w, losses=n - w, pct=shrunk_pct(w, n),
                last5=(last5.sum() + 1) / (len(last5) + 2), last10=(last10.sum() + 1) / (len(last10) + 2),
                streak=streak, prev_result=(np.nan if n == 0 else int(g.win.iloc[-1])), rest=rest,
                home_pct=shrunk_pct(hw, len(home_g)))


def ranks_before(games_before: pd.DataFrame, teams):
    pct = {t: team_state(games_before, t, pd.Timestamp("2100-01-01"))["pct"] for t in teams}
    s = pd.Series(pct).rank(ascending=False, method="average")
    return s.to_dict()


def build_odi(league_att: pd.DataFrame, res: pd.DataFrame) -> pd.DataFrame:
    """Opponent Draw Index inputs: for every league game with known home attendance,
    ratio = attendance / that home team's mean attendance in that season."""
    m = league_att.merge(res[["season_code", "game_no", "home", "away"]], on=["season_code", "game_no"])
    m["home_season_mean"] = m.groupby(["season_code", "home"]).attendance.transform("mean")
    m["ratio"] = m.attendance / m.home_season_mean
    return m


def opponent_draw_index(odi_tbl, opp, season_code):
    past = odi_tbl[(odi_tbl.away == opp) & (odi_tbl.season_code < season_code)]  # strictly earlier seasons
    n = len(past)
    return (past.ratio.sum() + ODI_K * 1.0) / (n + ODI_K), n


def main():
    res = pd.read_csv(PROC / "league_games.csv", parse_dates=["date"], dtype={"start_time": str})
    kt_att = pd.read_csv(RAW / "kbl_kt_home_attendance_raw.csv", dtype={"date_mmdd": str})
    kt_att = kt_att[kt_att.game_type == "정규경기"].copy()
    inv = {v: k for k, v in SEASONS.items()}
    kt_att["season_code"] = kt_att.season.str.replace("20", "", 1).str.replace("-20", "-", regex=False).map(
        {"22-23": "S41", "23-24": "S43", "24-25": "S45", "25-26": "S47"})
    league_att = pd.read_csv(RAW / "kbl_league_home_attendance_raw.csv")
    weather = pd.read_csv(PROC / "weather_suwon_daily.csv", parse_dates=["date"])
    hol = pd.read_csv(RAW / "kr_public_holidays_2022_2026.csv", parse_dates=["date"])
    hol_set = set(hol.date)
    odi_tbl = build_odi(league_att, res)

    kt_home = res[res.home == "KT"].merge(
        kt_att[["season_code", "game_no", "round", "venue", "attendance"]], on=["season_code", "game_no"], how="left")
    kt_home = kt_home.sort_values(["date", "start_time"]).reset_index(drop=True)

    season_span = res.groupby("season_code").date.agg(["min", "max"])
    teams = sorted(res.home.unique())
    rows = []
    for _, g in kt_home.iterrows():
        before = res[(res.season_code == g.season_code) & (res.date < g.date)]
        kt = team_state(before, "KT", g.date)
        op = team_state(before, g.away, g.date)
        rk = ranks_before(before, teams)
        odi, odi_n = opponent_draw_index(odi_tbl, g.away, g.season_code)
        span = season_span.loc[g.season_code]
        d = g.date
        rows.append(dict(
            season=g.season, season_code=g.season_code, game_id=g.game_id, game_no=g.game_no, game_date=d.date(),
            start_time=f"{g.start_time[:2]}:{g.start_time[2:]}", home_team="KT", away_team=g.away,
            opponent=TEAM_KO[g.away], venue=g.venue, round=int(g["round"]), attendance=int(g.attendance),
            game_type="regular_season",
            post_KT_score=int(g.home_score), post_opp_score=int(g.away_score),
            post_result="W" if g.home_win == 1 else "L",
            # --- team performance BEFORE the game
            pregame_KT_wins=kt["wins"], pregame_KT_losses=kt["losses"], pregame_KT_games=kt["games"],
            pregame_KT_win_pct=round(kt["pct"], 4), pregame_KT_rank=rk["KT"],
            KT_last5_win_pct=round(kt["last5"], 4), KT_last10_win_pct=round(kt["last10"], 4),
            KT_streak=kt["streak"], previous_game_result=kt["prev_result"],
            days_since_last_game=kt["rest"], back_to_back=int(kt["games"] > 0 and kt["rest"] == 1),
            home_record_before_game=round(kt["home_pct"], 4),
            opponent_win_pct_before_game=round(op["pct"], 4), opponent_rank_before_game=rk[g.away],
            opponent_last5_win_pct=round(op["last5"], 4), opponent_days_rest=op["rest"],
            # --- calendar
            day_of_week=d.dayofweek, weekend_flag=int(d.dayofweek >= 5), saturday=int(d.dayofweek == 5),
            sunday=int(d.dayofweek == 6), public_holiday=int(d in hol_set),
            weekday_holiday=int(d in hol_set and d.dayofweek < 5), off_day=int(d.dayofweek >= 5 or d in hol_set),
            day_type=day_type(d, hol_set),
            holiday_eve=int((d + pd.Timedelta(days=1)) in hol_set), month=d.month,
            month_idx=(d.month - 10) % 12,  # Oct=0 ... Apr=6
            season_progress=round((d - span["min"]).days / (span["max"] - span["min"]).days, 4),
            start_hour=round(g.start_hour, 2), afternoon_game=int(g.start_hour < 17), evening_game=int(g.start_hour >= 17),
            # --- opponent draw index (prior seasons only)
            opponent_draw_index=round(odi, 4), opponent_draw_n=odi_n,
        ))
    df = pd.DataFrame(rows)
    # recent home-attendance momentum: previous KT home games only (never the current game); carries across seasons
    att = df.attendance.astype(float)
    df["previous_home_attendance"] = att.shift(1)
    df["rolling_3_home_attendance"] = att.shift(1).rolling(3, min_periods=1).mean()
    df["rolling_5_home_attendance"] = att.shift(1).rolling(5, min_periods=1).mean()
    season_codes = list(SEASONS)
    prior_season_means = {season_codes[i]: df[df.season_code == season_codes[i - 1]].attendance.mean()
                          for i in range(1, len(season_codes))}
    df["prior_season_mean_attendance"] = df.season_code.map(prior_season_means)
    # weather (same-day observation used as stand-in for a forecast; see README)
    df = df.merge(weather.drop(columns=["trace_flag"]).assign(game_date=lambda x: x.date.dt.date).drop(columns="date"),
                  on="game_date", how="left")
    df["near_capacity_flag"] = (df.attendance >= NEAR_CAPACITY_THRESHOLD).astype(int)
    df.to_csv(PROC / "game_level_dataset.csv", index=False)
    print(f"built {len(df)} games x {df.shape[1]} cols -> data/processed/game_level_dataset.csv")
    print(df.groupby("season").attendance.agg(["count", "mean", "median", "max"]).round(0))


if __name__ == "__main__":
    main()
