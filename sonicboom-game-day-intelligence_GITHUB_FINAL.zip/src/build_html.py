"""Step 7 - build the SELF-CONTAINED index.html.
Everything the page shows is embedded as one JSON object (const DATA=...). Major analysis values are rendered from DATA in JS,
and nothing is fetched at run time (works on GitHub Pages and from file://)."""
import json
import math
import numpy as np
import pandas as pd
from config import ROOT, OUT, TAB, PROC, RAW, FIG, OFFICIAL_SEAT_COUNT, NEAR_CAPACITY_THRESHOLD
from modeling_lib import FEATURE_LABELS

WEB = ROOT / "web"
ACCESSED = "2026-09-27"

def clean(o):
    if isinstance(o, dict): return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [clean(v) for v in o]
    if isinstance(o, (np.floating, float)): return None if (math.isnan(o) or math.isinf(o)) else float(o)
    if isinstance(o, np.integer): return int(o)
    if isinstance(o, np.bool_): return bool(o)
    return o

def recs(df): return clean(json.loads(df.to_json(orient="records", force_ascii=False)))

ds = pd.read_csv(PROC / "game_level_dataset.csv")
eda = json.load(open(OUT / "eda_payload.json"))
metrics = json.load(open(OUT / "model_metrics.json"))
planner = json.load(open(OUT / "planner_model.json"))
q = json.load(open(TAB / "data_quality_report.json"))
checks = pd.read_csv(TAB / "data_quality_checks.csv")
bt = pd.read_csv(TAB / "backtest_predictions.csv")
imp = {m: pd.read_csv(TAB / f"feature_importance_model_{m}.csv") for m in "AB"}
opp_eff = {m: pd.read_csv(TAB / f"opponent_effects_model_{m}.csv", index_col=0).iloc[:, 0].to_dict() for m in "AB"}
sel = pd.read_csv(TAB / "model_selection_log.csv")
cases_up = pd.read_csv(TAB / "residual_cases_above.csv"); cases_dn = pd.read_csv(TAB / "residual_cases_below.csv")
league_games = pd.read_csv(PROC / "league_games.csv", parse_dates=["date"])
league_att = pd.read_csv(RAW / "kbl_league_home_attendance_raw.csv")
standings_raw = pd.read_csv(RAW / "kbl_official_final_standings.csv")
weather_daily = pd.read_csv(PROC / "weather_suwon_daily.csv")
holidays_raw = pd.read_csv(RAW / "kr_public_holidays_2022_2026.csv")

sources = [
  dict(name="KBL 경기 결과(정규시즌 전 경기)", tier="KBL 공식", url="https://www.kbl.or.kr/match/schedule", period=f"{league_games.date.min().date()} ~ {league_games.date.max().date()}", rows=f"{len(league_games):,}경기"),
  dict(name="KBL 경기별 관중 (KT 홈 + 타 구단 홈)", tier="KBL 공식", url="https://www.kbl.or.kr/record/crowd", period="2022-23 ~ 2025-26", rows=f"KT {len(ds)} · 전체 {len(league_att):,}"),
  dict(name="KBL 최종 순위표 (승패 교차검증)", tier="KBL 공식", url="https://www.kbl.or.kr/match/team-ranking", period="2022-23 ~ 2025-26", rows=f"{len(standings_raw)} 팀-시즌"),
  dict(name="수원KT소닉붐아레나 좌석수", tier="구단 공식(KBL)", url="https://sonicboom.kbl.or.kr/team/stadium", period="일자 미표기", rows=f"{OFFICIAL_SEAT_COUNT:,}석"),
  dict(name="기상청 날씨누리 과거관측 일별자료 (ASOS 수원 119)", tier="기상청", url="https://www.weather.go.kr/w/weather/land/past-obs/obs-by-day.do?stn=119&yy=2022&mm=10&obs=1", period=f"경기일 {len(weather_daily)}일", rows=f"{len(weather_daily)}일"),
  dict(name="대한민국 공휴일 캘린더", tier="법령·정부 공고", url="https://www.law.go.kr/lsInfoP.do?lsId=002404", period="2022-10 ~ 2026-04", rows=f"저장 목록 {len(holidays_raw)}일"),
]
source_links = [
  dict(t="KBL 경기일정·결과", url="https://www.kbl.or.kr/match/schedule", n="경기 결과, 시작시간, 경기장"),
  dict(t="KBL 관중현황", url="https://www.kbl.or.kr/record/crowd", n="경기별 관중수"),
  dict(t="KBL 팀순위", url="https://www.kbl.or.kr/match/team-ranking", n="직접 계산한 승패의 교차검증"),
  dict(t="수원KT소닉붐아레나(구단 페이지)", url="https://sonicboom.kbl.or.kr/team/stadium", n=f"좌석수 {OFFICIAL_SEAT_COUNT:,}석, 주소"),
  dict(t="기상청 날씨누리 과거관측", url="https://www.weather.go.kr/w/observation/land/past-obs/obs-by-day.do", n="ASOS 수원(119) 일 기온·강수"),
  dict(t="관공서의 공휴일에 관한 규정 (국가법령정보센터)", url="https://www.law.go.kr/lsInfoP.do?lsId=002404", n="법정·대체공휴일 기준"),
  dict(t="2026년 월력요항 (우주항공청 공지)", url="https://www.kasa.go.kr/bbs/BBSMSTR_000000000010/view.do?nttId=B000000001860Pe2zT3", n="2026 공휴일·대체공휴일"),
  dict(t="'1월 27일' 설 임시공휴일로 지정 (정책브리핑)", url="https://www.korea.kr/news/policyNewsView.do?newsId=148938559", n="2025-01-27 임시공휴일"),
  dict(t="2021-22 KBL 수도권 관중 제한 배경 (연합뉴스)", url="https://www.yna.co.kr/view/AKR20211015138500007", n="수원 KT 포함 수도권 5개 구단 무관중 개막 후 수용 규모 20% 입장 허용"),
]
observed_max = int(ds.attendance.max())
n_observed_max = int((ds.attendance == observed_max).sum())
season_max_text = " → ".join(f"{int(v):,}" for v in ds.groupby("season", sort=False).attendance.max())
missing_league_att = len(league_games) - len(league_att)
coverage_league_att = len(league_att) / len(league_games)
dq_issues = [
  "<b>분석 범위</b>: 2022-23~2025-26 정규리그 홈경기만 사용했습니다. 2021-22 시즌은 수원 KT를 포함한 수도권 5개 구단이 무관중으로 개막한 뒤 수용 규모 20% 제한이 적용되는 등 관중 수용 조건이 달랐던 시기라 시즌 간 비교 가능성을 위해 제외했습니다. 플레이오프·챔피언결정전도 제외했습니다.",
  f"<b>타 구단 관중 결측</b>: 일부 팀-시즌의 경기별 관중이 KBL 관중 페이지에서 조회되지 않아 {missing_league_att:,}경기가 상대팀 흥행지수 계산 원자료에서 빠졌습니다(리그 관중 {len(league_att):,}/{len(league_games):,}경기, {coverage_league_att:.1%}). 흥행지수는 조회된 경기만으로 계산했고, 첫 시즌(2022-23)은 이전 시즌이 없어 중립값 1.0입니다.",
  f"<b>좌석 수용인원 미검증</b>: 구단 페이지에 {OFFICIAL_SEAT_COUNT:,}석이 안내되어 있지만 일자가 없고 시즌별 변경 이력은 확인하지 못했습니다. 시즌별 관측 최댓값은 {season_max_text}명이며, 전체 관측 최댓값 {observed_max:,}명은 {n_observed_max}회였습니다. 그래서 점유율(occupancy_rate)은 계산하지 않고, ‘관중 ≥ {NEAR_CAPACITY_THRESHOLD:,}명’을 만석 근접 표지로만 사용했습니다(공식 매진 표기가 아님).",
  "<b>날씨</b>: 기상청 일 단위 값(평균·최고·최저기온, 운량, 일 강수량)만 확보했습니다. 풍속·적설·경기시간대 값은 수집하지 못했고, 강수량 ‘-’ 표시는 0mm로 변환했습니다. 모델에는 경기 당일 관측값을 예보의 대용으로 썼습니다(실무에서는 예보를 써야 함).",
  "<b>경기 후 정보 제외</b>: 점수·승패·연장 여부는 경기 후에야 알 수 있어 예측 변수에서 뺐고(<code>post_</code> 접두), 연장 여부는 수집하지 않았습니다.",
  "<b>이벤트·프로모션</b>: 경기 단위로 일관되게 수집할 수 있는 공식 자료가 없어 모델 변수에서 제외했습니다.",
  "<b>상대팀 표시명</b>: 시즌 중 명칭·연고지 변경을 과거 경기에도 소급해 표시하지 않도록 KCC는 연고지 없이, 고양은 ‘캐롯·소노’, 안양은 ‘KGC·정관장’으로 표기했습니다. 모델은 KBL 팀 코드를 사용합니다.",
  "<b>결측 처리</b>: 이전 홈경기 관중 변수는 2022-23 첫 경기 1건이 결측이며, 직전 시즌 평균 관중은 2022-23 전체가 결측입니다. 모두 학습셋 중앙값으로 대체했습니다(교차검증 폴드마다 학습셋에서만 계산).",
]
actions = [
  dict(t="시즌 일정 발표 직후 경기별 기본 수요 등급 산출", d="Model A(요일 유형·시즌 시점·상대·직전 시즌 레벨)만으로 홈 27경기를 LOW/MID/HIGH로 분류해 프로모션 캘린더 초안과 기본 인력·MD 계획의 출발점으로 씁니다. 요일 유형 관련 변수가 중요도 상위에 나타나 평일 경기가 LOW 후보로 모이는 구조를 미리 볼 수 있습니다."),
  dict(t="경기 주간에 팀 성적과 날씨를 반영해 업데이트", d="Model B로 등급이 바뀌는지 확인합니다. 다만 이번 백테스트에서 경기주간 정보의 추가 이득은 작고 시즌마다 달랐으므로, 큰 조정이 아니라 ‘등급 이동 여부 확인’ 용도로 쓰는 것이 타당합니다."),
  dict(t="LOW 수요 예상 경기에서 프로모션 후보 선정", d="LOW 등급 경기를 프로모션 검토 대상으로 올리고, 예측범위 하단과 과거 평일 저녁 경기의 실제 분포를 함께 봅니다. 실제 시행 여부와 종류는 내부 예매 속도·비용 자료가 있어야 판단할 수 있습니다."),
  dict(t="HIGH 수요 예상 경기에서 현장 운영·재고 점검 강화", d="입장·매점·MD 동선, 인력, 재고를 우선 점검합니다. 만석 근접 경기는 관측 관중이 좌석 상한에 걸려 실제 수요가 더 컸을 수 있으므로, 예측 상단까지 대비하는 것이 안전합니다."),
]
limits = [
  "실제 예매 속도(D-30/D-14/D-7/D-1) 데이터가 없습니다.", "좌석등급별 판매량이 없습니다.", "시즌권·초청권·무료입장 구분이 없고, KBL 공표 관중수의 집계 기준도 확인하지 못했습니다.",
  "CRM·회원 정보가 없습니다.", "MD 판매·재고 데이터가 없습니다(§10은 시나리오 도구일 뿐입니다).", "프로모션·광고 노출량이 없습니다.",
  "매진에 가까운 경기는 잠재 수요(latent demand)를 확인할 수 없습니다. Attendance ≠ True Demand.", f"표본이 수원 KT 한 구단 {ds.season.nunique()}시즌, {len(ds)}경기로 작습니다. 상대팀·요일 효과의 신뢰구간이 넓습니다.",
  "분석은 상관과 예측이며 인과효과 분석이 아닙니다. 변수 중요도도 인과효과가 아닙니다.", "모델은 시즌 평균 관중의 상승 추세를 따라가지 못해 백테스트 3개 시즌 모두 과소예측했습니다.",
  "날씨는 일 단위 관측값이며 예보가 아닙니다. 풍속·적설은 수집하지 못했습니다. 경기주간에 실제 사용하려면 같은 변수 정의의 예보값으로 교체해야 합니다.",
  "변수 구성과 모델 선택 과정에 본 데이터의 탐색 결과가 활용되었고, 후보 모델 선택과 성능 요약에도 같은 expanding-window 백테스트를 사용했습니다. 따라서 별도의 untouched 최종 holdout 성능은 아니며, 표시된 성능에는 개발 과정의 선택 영향이 일부 포함될 수 있습니다. 데이터가 더 쌓이면 이후 시즌을 최종 검증용으로 남기는 것이 필요합니다.",
]
internal = ["예매 D-30 / D-14 / D-7 / D-1 curve", "좌석등급별 수요", "시즌권 / 일반권 분리", "신규 / 재방문 팬", "CRM 세그먼트", "MD SKU별 판매", "프로모션 exposure", "구매전환", "팬 LTV(생애가치)"]

dmap = ds.set_index("game_id")[["day_type", "start_time"]]
cases_up = cases_up.join(dmap, on="game_id"); cases_dn = cases_dn.join(dmap, on="game_id")
btd = bt.join(dmap, on="game_id")
err_by_day = [dict(day_type=k, n=int(len(g)), MAE_B=float(g.resid_B.abs().mean()), MAE_A=float(g.resid_A.abs().mean()), bias_B=float(g.resid_B.mean())) for k, g in btd.groupby("day_type")]
err_by_cap = [dict(near_capacity=int(k), n=int(len(g)), MAE_B=float(g.resid_B.abs().mean()), bias_B=float(g.resid_B.mean())) for k, g in btd.groupby("near_capacity_flag")]
payload = dict(errByDay=err_by_day, errByCap=err_by_cap, nearCapacityThreshold=NEAR_CAPACITY_THRESHOLD, observedMax=observed_max, 
    accessed=ACCESSED, nCols=int(ds.shape[1]), priorMean=float(ds[ds.season_code == "S47"].attendance.mean()),
    eda=eda, metrics=metrics, comparison=recs(pd.read_csv(TAB / "model_comparison.csv")), planner=planner,
    selection=recs(sel[sel.eligible]), backtest=recs(bt), importance={m: recs(imp[m]) for m in "AB"}, oppEffects=clean(opp_eff),
    sellout=recs(pd.read_csv(TAB / "sellout_sensitivity.csv")), drift=recs(pd.read_csv(TAB / "drift_by_season.csv")),
    casesAbove=recs(cases_up), casesBelow=recs(cases_dn),
    quality=dict(funnel=recs(pd.read_csv(TAB / "data_funnel.csv")), checks=recs(checks), report=recs(pd.read_csv(TAB / "data_quality_report.csv"))),
    sources=sources, sourceLinks=source_links, dqIssues=dq_issues, actions=actions, limits=limits, internal=internal,
    labels=FEATURE_LABELS)
js_data = json.dumps(clean(payload), ensure_ascii=False, allow_nan=False, separators=(",", ":")).replace("</", "<\\/")
html = f"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SONICBOOM GAME DAY INTELLIGENCE</title>
<meta name="description" content="수원 KT 소닉붐 홈경기 관중 수요 예측과 경기일 비즈니스 의사결정 - 공개데이터 기반 개인 포트폴리오">
<style>
{(WEB / 'style.css').read_text(encoding='utf-8')}
</style></head><body>
{(WEB / 'body.html').read_text(encoding='utf-8')}
<script>const DATA={js_data};</script>
<script>
{(WEB / 'app.js').read_text(encoding='utf-8')}
</script></body></html>"""
(ROOT / "index.html").write_text(html, encoding="utf-8")
print(f"index.html written: {len(html)/1024:.0f} KB (data payload {len(js_data)/1024:.0f} KB)")
