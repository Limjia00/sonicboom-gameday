"""Writes README.md and outputs/SELF_AUDIT.md with numbers pulled from the generated outputs (nothing typed by hand)."""
import json
import pandas as pd
from config import ROOT, OUT, TAB, PROC, RAW, OFFICIAL_SEAT_COUNT

M = json.load(open(OUT / "model_metrics.json")); C = M["comparison"]; E = json.load(open(OUT / "eda_payload.json"))
ds = pd.read_csv(PROC / "game_level_dataset.csv"); gw = M["game_week_vs_advance"]; wk = E["weekend"]
league_games = pd.read_csv(PROC / "league_games.csv", parse_dates=["date"])
league_att = pd.read_csv(RAW / "kbl_league_home_attendance_raw.csv")
standings_raw = pd.read_csv(RAW / "kbl_official_final_standings.csv")
weather_daily = pd.read_csv(PROC / "weather_suwon_daily.csv")
holidays_raw = pd.read_csv(RAW / "kr_public_holidays_2022_2026.csv")
n_seasons = ds.season.nunique(); games_per_season = int(ds.groupby("season").size().iloc[0])
imp = pd.read_csv(TAB / "feature_importance_model_B.csv"); dr = pd.read_csv(TAB / "drift_by_season.csv")
f0 = lambda x: f"{x:,.0f}"
best = min(C[0]["MAE"], C[1]["MAE"], C[2]["MAE"])
tbl = "\n".join(f"| {r['MODEL']} | {f0(r['MAE'])} | {f0(r['RMSE'])} | {r['MAPE']:.1f}% | {r['R2']:.2f} | {f0(r['MAE_fold1_S43'])} | {f0(r['MAE_fold2_S45'])} | {f0(r['MAE_fold3_S47'])} |" for r in C)
bias = dr.pivot(index="model", columns="test_season", values="bias_actual_minus_pred").round(0)
readme = f"""# SONICBOOM GAME DAY INTELLIGENCE
**수원 KT 소닉붐 홈경기 관중 수요 예측과 경기일 비즈니스 의사결정** — 공개 데이터만 사용한 개인 포트폴리오 (KBL·KT 구단과 무관, 로고·선수 이미지 미사용)

`index.html` 하나로 동작하는 정적 대시보드입니다(외부 파일 fetch 없음, GitHub Pages·`file://` 모두 동작).

- **범위**: 정규리그 홈 {len(ds)}경기({n_seasons}시즌)
- **검증**: 시즌 단위 expanding-window, out-of-time 81경기
- **결과**: Model A MAE {f0(C[3]["MAE"])}명 · Model B MAE {f0(C[4]["MAE"])}명. 경기주간 정보의 추가 개선은 시즌별로 일관되지 않았습니다.

## 1. 프로젝트 질문
“다음 수원 KT 홈경기에는 몇 명이 올 가능성이 높고, 어떤 조건에서 관중 차이가 나타나는가? 그리고 그 정보를 경기일 운영 판단에 어떻게 참고할 수 있는가?”
시즌 일정 발표 시점(**Model A, 사전 계획**)과 경기 주간(**Model B, 경기주간 업데이트**)은 알 수 있는 정보가 다르므로 예측을 두 단계로 나눴습니다.

## 2. 데이터 (모두 공개·확인 가능, 조회일 2026-09-27)
| 데이터 | 출처 | 기간 | 행 |
|---|---|---|---|
| 경기 결과(정규시즌 전 경기) | KBL 공식 `/match/schedule` | {league_games.date.min().date()} ~ {league_games.date.max().date()} | {len(league_games):,}경기 |
| 경기별 관중 | KBL 공식 `/record/crowd` | 2022-23 ~ 2025-26 | KT 홈 {len(ds)} · 전체 {len(league_att):,} |
| 최종 순위표(직접 계산 승패 검증용) | KBL 공식 `/match/team-ranking` | {n_seasons}시즌 | {len(standings_raw)} 팀-시즌 |
| 좌석수 | 구단 페이지 `sonicboom.kbl.or.kr/team/stadium` | 일자 미표기 | {OFFICIAL_SEAT_COUNT:,}석 |
| 일 기온·강수 | 기상청 날씨누리 과거관측(ASOS 수원 119) | 경기일 | {len(weather_daily)}일 |
| 공휴일 | 국가법령정보센터 공휴일 규정 + 정부 임시공휴일 공고/월력요항 | 2022-10~2026-04 | 저장 목록 {len(holidays_raw)}일 |

분석 단위는 **수원 KT 정규리그 홈경기 1개 = 1행 (2022-23 ~ 2025-26, {n_seasons}시즌 × {games_per_season}경기 = {len(ds)}경기)**.
분석 범위는 2022-23~2025-26 정규리그로 고정했습니다. 2021-22 시즌은 수원 KT를 포함한 수도권 5개 구단이 무관중으로 개막한 뒤 수용 규모 20% 제한이 적용되는 등 관중 수용 조건이 달랐던 시기라 시즌 간 비교 가능성을 위해 제외했습니다([연합뉴스, 2021-10-15](https://www.yna.co.kr/view/AKR20211015138500007)). 플레이오프·챔피언결정전·컵대회도 포함하지 않았습니다.
**사용하지 않은/없는 데이터**: KT 내부 예매·MD·CRM 데이터(공개되지 않음), 경기별 이벤트·프로모션(일관 수집 불가), 풍속·적설·연장 여부, 타 구단 일부 홈 관중(가스공사 2022-25, 소노 2023-25: KBL 페이지에서 조회 불가).
상대팀 표시는 과거 경기에 현재 연고지/구단명을 소급하지 않도록 KCC, 고양 캐롯·소노, 안양 KGC·정관장처럼 시즌 간 비교에 안전한 명칭을 사용했습니다.

## 3. 분석 방법
- **경기 전 변수는 직접 계산**: 모든 팀 성적(승률·순위·최근 5경기·연승/연패·휴식일)은 해당 경기 **날짜 이전** 경기만으로 계산(시즌 최종 순위·승률 미사용). 자동 누수 점검 포함.
- **상대팀 흥행지수(ODI)**: 상대가 원정팀일 때 홈팀 시즌 평균 대비 관중 비율을 **이전 시즌만**으로 평균(표본 수축 k=3). 2022-23은 중립값 1.0.
- **캘린더**: 요일 유형(평일/토/일/평일 공휴일), 공휴일 전날, 시즌 시점. 낮 경기 변수는 데이터셋에 있지만 주말·공휴일 경기의 96%가 낮 경기라 **요일과 분리 불가**하여 모델 입력에서 제외(공선성 진단).
- **레벨 앵커**: 시즌 평균 관중이 1,548 → 2,472명으로 상승해, 다음 시즌 예측의 수준 기준으로 직전 시즌 평균 관중을 변수에 포함.
- **모델**: 후보 16개(Ridge / ElasticNet / RandomForest / HistGradientBoosting × 변수 4세트). 딥러닝 미사용. 선택 규칙: 폴드 2·3 통합 MAE 최저, 단 선형 모델이 5% 이내면 선형 선택. 채택: Model A = {M['spec']['A']['feature_set']} / {M['spec']['A']['model']}, Model B = {M['spec']['B']['feature_set']} / {M['spec']['B']['model']}. 전체 로그: `outputs/tables/model_selection_log.csv`.
- **예측구간**: 이전 폴드 out-of-time 잔차의 10·90분위수. **수요 등급**: 학습 시즌 관측 관중의 33·67분위수(LOW/MID/HIGH).

## 4. 검증 방법
랜덤 분할 미사용. **시즌 단위 확장 창 백테스트**: (학습 22-23 → 테스트 23-24) / (22-23~23-24 → 24-25) / (22-23~24-25 → 25-26). 폴드 1은 학습이 27경기뿐이라 보고만 하고 모델 선택에는 쓰지 않았습니다.

## 5. 결과 (81개 out-of-time 경기, 단위: 명)
| MODEL | MAE | RMSE | MAPE | R² | MAE 23-24 | 24-25 | 25-26 |
|---|---|---|---|---|---|---|---|
{tbl}

- 최고 단순 기준({f0(best)}) 대비 MAE 감소: Model A {M['improvement_vs_best_baseline_pct']['A']:.0f}%, Model B {M['improvement_vs_best_baseline_pct']['B']:.0f}%.
- **경기주간 정보 추가 효과**: 전체 MAE {gw['MAE_pooled_all_gain_pct']:.1f}% 감소, 폴드 2·3 {gw['MAE_folds2_3_gain_pct']:.1f}%, 시즌별 {gw['per_fold_gain_pct']['S43']:+.0f}% / {gw['per_fold_gain_pct']['S45']:+.0f}% / {gw['per_fold_gain_pct']['S47']:+.0f}% (양수=개선). → **일관된 개선이라고 주장하지 않습니다.**
- 80% 예측구간의 폴드 정직 커버리지: A {M['interval80']['A']['coverage']:.0%}, B {M['interval80']['B']['coverage']:.0%} (n={M['interval80']['B']['n']}). 수요 등급 정확 일치율 A {M['level_accuracy']['A']['exact']:.0%}, B {M['level_accuracy']['B']['exact']:.0%}.
- 주말 평균 {f0(wk['weekend_mean'])}명 vs 평일 {f0(wk['weekday_mean'])}명 (차이 {wk['diff']:+,.0f}, 95% CI {f0(wk['diff_boot95'][0])}~{f0(wk['diff_boot95'][1])}); 4시즌 모두 같은 방향.
- **모델은 세 시즌 모두 과소예측**했습니다(실제−예측 평균, 명):
{bias.to_string()}
- 상관≠인과, feature importance≠causal effect.

## 6. 실행 방법
```bash
pip install -r requirements.txt
python -m playwright install chromium   # verify_outputs.py의 브라우저 검증용 1회 설치
bash run_all.sh      # raw(data/raw) → 처리 → 검증 → 분석 → 모델 → index.html → 수치 자동검증
open index.html       # 또는 GitHub Pages
```
원자료(`data/raw`)는 공개 페이지(브라우저)에서 읽어 저장한 스냅샷입니다(절차: `src/browser_extraction_notes.md`). KBL/기상청 페이지는 JS 앱이라 스크립트만으로 재수집되지 않을 수 있어, 저장된 raw에서 시작해 이후 전 과정을 재현합니다. `src/verify_outputs.py`가 HTML의 주요 수치·브라우저 내 Planner 계산이 파이썬(scikit-learn) 결과와 일치하는지 자동 검증합니다.

폴더: `data/raw` · `data/processed` · `src/{{collect_kbl,collect_weather,build_dataset,validate_data,analysis,train_model}}.py` · `outputs/{{figures,tables,model_metrics.json}}` · `index.html`

## 7. 출처
KBL 공식 홈페이지(일정·결과·관중·순위·구단 페이지) / 기상청 날씨누리 과거관측 / 국가법령정보센터 공휴일 규정 / 정책브리핑(2025 임시공휴일) / 우주항공청(2026 월력요항) / 2021-22 관중 제한 배경(연합뉴스). URL 전체는 `index.html` 하단 SOURCES.

## 8. 한계
예매 속도·좌석등급·시즌권/초청권 구분·CRM·MD 판매·프로모션 노출 데이터 없음 · 매진 근접 경기는 잠재 수요 확인 불가(Attendance ≠ True Demand; 좌석수 이력 미검증이라 점유율 분석 제외) · 한 구단 {n_seasons}시즌 {len(ds)}경기로 표본 작음 · 상관·예측 분석이며 인과 분석 아님 · 백테스트 {dr.test_season.nunique()}개 시즌 모두 과소예측 · 날씨는 일 단위 관측(예보 아님, 풍속·적설 미수집).
변수 구성과 모델 선택 과정에 본 데이터의 탐색 결과가 활용되었고, 후보 모델 선택과 성능 요약에도 같은 expanding-window 백테스트를 사용했습니다. 따라서 별도의 untouched 최종 holdout 성능은 아니며, 표시된 성능에는 개발 과정의 선택 영향이 일부 포함될 수 있습니다. 데이터가 더 쌓이면 이후 시즌을 최종 검증용으로 남기는 것이 필요합니다.
KT 내부 데이터가 있다면: 예매 D-30/14/7/1 curve, 좌석등급별 수요, 시즌권/일반권 분리, 신규/재방문 팬, CRM 세그먼트, MD SKU별 판매, 프로모션 exposure, 구매전환, 팬 LTV.
"""
(ROOT / "README.md").write_text(readme, encoding="utf-8")
audit = """# SELF-AUDIT (채용 담당자 관점)
| # | 질문 | 답 | 근거 |
|---|---|---|---|
| 1 | 실제 데이터인가? | YES | KBL·기상청·정부 공개 자료의 저장 원자료를 사용, 임의 수치 생성 없음 |
| 2 | 출처를 확인할 수 있는가? | YES | URL·조회일·기간·행 수 표기(§02, README) |
| 3 | 데이터 누수가 없는가? | YES | 경기 전 변수는 날짜 이전 경기만 사용, 자동 스팟체크(validate_data.py), ODI는 이전 시즌만 |
| 4 | 경기 전에 알 수 있는 정보만 썼나? | PARTIAL | Model B의 날씨는 경기일 실제 관측값을 예보 대용으로 사용. 실무 적용 시 동일 정의의 예보값으로 교체 필요 |
| 5 | Baseline과 비교했는가? | YES | 3개 baseline |
| 6 | 미래 시즌 검증을 했는가? | YES | 확장 창 시즌 백테스트. 다만 변수 구성·모델 선택에 동일 데이터의 탐색 결과가 활용됐고 별도 untouched 최종 holdout은 없음 |
| 7 | 모델이 틀리는 경우도 보여주는가? | YES | §05 편향·§08 전체 경기·§09 TOP5 |
| 8 | 상관과 인과를 구분했는가? | YES | §04·§06·§12에서 관찰 패턴·중요도와 인과효과를 명확히 구분 |
| 9 | KT 내부데이터를 가진 척하지 않았는가? | YES | §10 시나리오 도구 문구, §12 |
| 10 | 실무 활용 범위를 과장하지 않았는가? | YES | §10은 가정 기반 시나리오, §11은 권고 예시로 구분하고 자동 의사결정이 아님을 명시 |
| 11 | 차트가 질문에 답하는가? | YES | 핵심 차트에 해석 문장과 비인과 한계를 함께 표기 |
| 12 | README만으로 이해되는가? | YES | README 1~8 |
| 13 | GitHub Pages에서 깨지지 않는가? | YES | 외부 리소스·fetch 없는 self-contained index.html 구조 |
| 14 | 30초 안에 핵심을 이해하는가? | YES | 히어로 KPI + 30초 요약 |
| 15 | 단순 선수기록 분석과 다른 능력을 보여주는가? | YES | 시간검증·누수 통제·불확실성·비즈니스 연결 |
"""
(OUT / "SELF_AUDIT.md").write_text(audit, encoding="utf-8")
print("README.md and SELF_AUDIT.md written")
