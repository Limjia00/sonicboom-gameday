"""Step 1 - assemble KBL raw extracts into tidy tables and verify them.

IMPORTANT (reproducibility note)
--------------------------------
The raw KBL numbers were read from KBL's own public web pages in a normal browser session
(no login, no access-control bypass, no file download):

  * League schedule/results  : https://www.kbl.or.kr/match/schedule   (month view, 정규시즌)
  * Per-game attendance      : https://www.kbl.or.kr/record/crowd     (팀 관중현황: team x season)
  * Official final standings : https://www.kbl.or.kr/match/team-ranking (used ONLY to cross-check results)
  * Arena seat count         : https://sonicboom.kbl.or.kr/team/stadium

The pages are JavaScript apps, so extraction was done by reading the rendered DOM in the browser
(see src/browser_extraction_notes.md for the exact procedure). The extracts were saved verbatim
into data/raw/*.csv. This script starts from those saved raw files, so everything downstream
(dataset, validation, models, HTML) is fully reproducible with `python src/*.py`.

Access date: 2026-09-27.
"""
import pandas as pd
from config import RAW, PROC, SEASONS


def load_results() -> pd.DataFrame:
    frames = []
    for sc, label in SEASONS.items():
        d = pd.read_csv(RAW / f"kbl_league_results_{sc}.csv", dtype={"yymmdd": str, "hhmm": str})
        d["season_code"] = sc
        d["season"] = label
        d["date"] = pd.to_datetime("20" + d["yymmdd"], format="%Y%m%d")
        d["start_time"] = d["hhmm"].str.zfill(4)
        d["start_hour"] = d["start_time"].str[:2].astype(int) + d["start_time"].str[2:].astype(int) / 60
        d["home_win"] = (d["home_score"] > d["away_score"]).astype(int)
        frames.append(d)
    res = pd.concat(frames, ignore_index=True)
    res["game_id"] = res["season_code"] + "-G" + res["game_no"].astype(str).str.zfill(3)
    return res.sort_values(["date", "start_time", "game_no"]).reset_index(drop=True)


def verify_against_official_standings(res: pd.DataFrame) -> pd.DataFrame:
    """Recompute W/L per team from scraped scores and compare to KBL's official standings table."""
    off = pd.read_csv(RAW / "kbl_official_final_standings.csv")
    rows = []
    for _, o in off.iterrows():
        g = res[res.season_code == o.season_code]
        w = ((g.home == o.team) & (g.home_win == 1)).sum() + ((g.away == o.team) & (g.home_win == 0)).sum()
        rows.append(dict(season_code=o.season_code, team=o.team, official_W=o.W, computed_W=int(w),
                         official_L=o.L, computed_L=int(54 - w), match=bool(w == o.W and 54 - w == o.L)))
    return pd.DataFrame(rows)


def main():
    res = load_results()
    res.to_csv(PROC / "league_games.csv", index=False)
    chk = verify_against_official_standings(res)
    chk.to_csv(PROC / "check_standings_vs_official.csv", index=False)
    print(f"league games: {len(res)}  | standings check: {chk.match.sum()}/{len(chk)} team-seasons match official W-L")
    att = pd.read_csv(RAW / "kbl_league_home_attendance_raw.csv")
    print(f"league home-attendance rows: {len(att)}")


if __name__ == "__main__":
    main()
