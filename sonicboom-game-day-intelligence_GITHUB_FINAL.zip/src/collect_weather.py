"""Step 1b - clean KMA ASOS daily data (Suwon, station 119) that was read from
https://www.weather.go.kr/w/observation/land/past-obs/obs-by-day.do?stn=119&yy=YYYY&mm=M&obs=1
(the page states it serves 기상자료개방포털 ASOS values via API). Access date 2026-09-27.

Only the 108 KT home-game dates were extracted. Variables available on that page:
mean/max/min temperature, mean cloud amount, daily precipitation.
NOT available on that page (therefore NOT used): wind speed, snowfall/snow depth, hourly values.

Precipitation coding
  '-'      -> 0.0 mm (page shows '-' when no precipitation recorded)
  '0.0mm'  -> trace (<0.05mm recorded as 0.0); treated as 0 mm, tracked as trace_flag
  'x.xmm'  -> x.x
rain_flag = precip_mm >= 0.1
Caveat: '-' can theoretically also mean a missing observation; the page itself does not distinguish.
"""
import pandas as pd
from config import RAW, PROC


def main():
    w = pd.read_csv(RAW / "kma_asos_suwon119_daily_raw.csv", dtype={"date": str, "precip_raw": str})
    w["date"] = pd.to_datetime(w["date"], format="%Y%m%d")
    w["trace_flag"] = (w.precip_raw == "0.0mm").astype(int)
    w["precip_mm"] = w.precip_raw.str.replace("mm", "", regex=False).replace("-", "0").astype(float)
    w["rain_flag"] = (w.precip_mm >= 0.1).astype(int)
    w = w.rename(columns={"tavg": "temp_avg", "tmax": "temp_max", "tmin": "temp_min", "cloud": "cloud_avg"})
    w.drop(columns="precip_raw").to_csv(PROC / "weather_suwon_daily.csv", index=False)
    print(f"weather rows: {len(w)}, rain days: {int(w.rain_flag.sum())}, trace days: {int(w.trace_flag.sum())}")


if __name__ == "__main__":
    main()
