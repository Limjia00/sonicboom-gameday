"""Shared configuration for the SONICBOOM GAME DAY INTELLIGENCE pipeline."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROC = ROOT / "data" / "processed"
OUT = ROOT / "outputs"
FIG = OUT / "figures"
TAB = OUT / "tables"
for p in (PROC, FIG, TAB):
    p.mkdir(parents=True, exist_ok=True)

SEASONS = {"S41": "2022-23", "S43": "2023-24", "S45": "2024-25", "S47": "2025-26"}
TEAM_KO = {
    "KT": "수원 KT", "KCC": "KCC", "SK": "서울 SK", "GS": "대구 한국가스공사",
    "SN": "고양 캐롯·소노", "LG": "창원 LG", "JK": "안양 KGC·정관장", "HM": "울산 현대모비스",
    "DB": "원주 DB", "SS": "서울 삼성",
}
# Four-season comparison uses one internal code for renamed/relocated team slots; display labels avoid applying a later city/name to earlier seasons.
NEAR_CAPACITY_THRESHOLD = 3500      # ~95.6% of the 3,660 official seat count on sonicboom.kbl.or.kr (see README)
OFFICIAL_SEAT_COUNT = 3660          # sonicboom.kbl.or.kr/team/stadium (undated; season-by-season history NOT verified)
SHRINK_K = 5                        # pseudo-games for shrunk win-pct (prior 0.5)
REST_CAP = 14
RANDOM_STATE = 42
