"""Shared modelling code: feature sets, pipelines, expanding-window season backtest, metrics."""
import warnings
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import RidgeCV, ElasticNetCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from config import PROC, RANDOM_STATE

warnings.filterwarnings("ignore")

# ---- Feature sets --------------------------------------------------------------------------------------------
# MODEL A (ADVANCE PLANNING): everything is knowable when the season schedule is published.
# NOTE (collinearity diagnosis, done before the final grid): 47 of 49 weekend games and all 6 weekday-holiday games are
# afternoon games, so "afternoon_game" cannot be separated from "weekend/holiday". Day type is therefore encoded as
# saturday / sunday / weekday_holiday (base = ordinary weekday) and start-time is NOT a separate model feature.
# Attendance level shifts across these 4 observed seasons (season means 1,548 -> 2,133 -> 2,267 -> 2,472), so a level anchor
# that is known when the schedule is published - last season's mean attendance - is part of the core set.
# (For the first observed season it is missing and is median-imputed inside the pipeline.)
ADV_CORE = ["saturday", "sunday", "weekday_holiday", "holiday_eve", "month_idx", "season_progress",
            "opponent_draw_index", "prior_season_mean_attendance"]
# MODEL B (GAME-WEEK UPDATE): advance features + information that only exists shortly before tip-off.
GW_EXTRA = ["pregame_KT_win_pct", "pregame_KT_rank", "KT_last5_win_pct", "KT_streak", "days_since_last_game",
            "home_record_before_game", "opponent_win_pct_before_game", "opponent_rank_before_game",
            "opponent_last5_win_pct", "rolling_3_home_attendance", "rain_flag", "temp_avg"]
GW_CORE = ADV_CORE + GW_EXTRA
OPP_DUMMIES_PREFIX = "opp_"

FEATURE_LABELS = {
    "saturday": "토요일 경기", "sunday": "일요일 경기", "weekday_holiday": "평일 공휴일", "holiday_eve": "공휴일 전날",
    "month_idx": "시즌 내 월(10월=0)", "season_progress": "시즌 진행도", "afternoon_game": "낮 경기(17시 이전)",
    "opponent_draw_index": "상대팀 흥행지수(전 시즌)", "prior_season_mean_attendance": "직전 시즌 평균 관중(레벨 기준)", "pregame_KT_win_pct": "KT 경기 전 승률(수축 추정)",
    "pregame_KT_rank": "KT 경기 전 순위(승률 기준)", "KT_last5_win_pct": "KT 최근 5경기 승률(수축 추정)", "KT_streak": "KT 연승(+)/연패(-)",
    "days_since_last_game": "KT 휴식일", "home_record_before_game": "KT 홈 승률(수축 추정)",
    "opponent_win_pct_before_game": "상대 경기 전 승률(수축 추정)", "opponent_rank_before_game": "상대 경기 전 순위(승률 기준)",
    "opponent_last5_win_pct": "상대 최근 5경기 승률(수축 추정)", "rolling_3_home_attendance": "최근 3 홈경기 평균 관중",
    "rain_flag": "강수(≥0.1mm)", "temp_avg": "평균기온",
}


def load_dataset() -> pd.DataFrame:
    df = pd.read_csv(PROC / "game_level_dataset.csv", parse_dates=["game_date"])
    for t in sorted(df.away_team.unique()):
        df[OPP_DUMMIES_PREFIX + t] = (df.away_team == t).astype(int)
    return df


def opp_cols(df):
    return [c for c in df.columns if c.startswith(OPP_DUMMIES_PREFIX)]


def make_estimator(kind: str, log_target: bool = False):
    if kind == "ridge":
        est = RidgeCV(alphas=np.logspace(-1, 3, 30))
        pre = Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())])
        model = Pipeline([("pre", pre), ("est", est)])
    elif kind == "enet":
        est = ElasticNetCV(l1_ratio=[0.2, 0.5, 0.8], cv=5, random_state=RANDOM_STATE, max_iter=20000)
        pre = Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())])
        model = Pipeline([("pre", pre), ("est", est)])
    elif kind == "rf":
        model = Pipeline([("imp", SimpleImputer(strategy="median")),
                          ("est", RandomForestRegressor(n_estimators=400, min_samples_leaf=3, max_features=0.5,
                                                        random_state=RANDOM_STATE, n_jobs=-1))])
    elif kind == "hgb":
        model = Pipeline([("imp", SimpleImputer(strategy="median")),
                          ("est", HistGradientBoostingRegressor(max_depth=2, learning_rate=0.05, max_iter=150,
                                                                min_samples_leaf=6, l2_regularization=1.0,
                                                                random_state=RANDOM_STATE))])
    else:
        raise ValueError(kind)
    return model


def fit_predict(kind, Xtr, ytr, Xte, log_target=False):
    m = make_estimator(kind)
    y = np.log(ytr) if log_target else ytr
    m.fit(Xtr, y)
    p = m.predict(Xte)
    return (np.exp(p) if log_target else p), m


def metrics(y, p):
    y = np.asarray(y, float); p = np.asarray(p, float)
    err = y - p
    ss_res = (err ** 2).sum(); ss_tot = ((y - y.mean()) ** 2).sum()
    return dict(MAE=float(np.abs(err).mean()), RMSE=float(np.sqrt((err ** 2).mean())),
                MAPE=float((np.abs(err) / y).mean() * 100), R2=float(1 - ss_res / ss_tot), n=int(len(y)))


FOLDS = [(["S41"], "S43"), (["S41", "S43"], "S45"), (["S41", "S43", "S45"], "S47")]


def backtest_baselines(df):
    out = {}
    rows = []
    for tr_s, te_s in FOLDS:
        tr = df[df.season_code.isin(tr_s)]; te = df[df.season_code == te_s]
        rows.append(pd.DataFrame(dict(game_id=te.game_id.values, fold=te_s, y=te.attendance.values,
            B1_train_mean=tr.attendance.mean(),
            B1b_prior_season_mean=df[df.season_code == tr_s[-1]].attendance.mean(),
            B2_last5_home_mean=te.rolling_5_home_attendance.fillna(tr.attendance.mean()).values)))
    return pd.concat(rows, ignore_index=True)


def backtest_model(df, feats, kind, log_target=False):
    preds = []
    for tr_s, te_s in FOLDS:
        tr = df[df.season_code.isin(tr_s)]; te = df[df.season_code == te_s]
        p, _ = fit_predict(kind, tr[feats], tr.attendance.values, te[feats], log_target)
        preds.append(pd.DataFrame(dict(game_id=te.game_id.values, fold=te_s, y=te.attendance.values, pred=p)))
    return pd.concat(preds, ignore_index=True)


def summarize(pred_df, col="pred"):
    res = {}
    for f, g in pred_df.groupby("fold"):
        res[f] = metrics(g.y, g[col])
    res["pooled_all"] = metrics(pred_df.y, pred_df[col])
    g23 = pred_df[pred_df.fold.isin(["S45", "S47"])]
    res["pooled_folds2_3"] = metrics(g23.y, g23[col])
    return res
