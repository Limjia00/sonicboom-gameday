"""Step 5 - time-honest model comparison (expanding-window SEASON backtest), final models, intervals, importance.

Design (recorded in outputs/tables/model_selection_log.csv):
  * Candidate grid : feature sets {A, A+opp, B, B+opp} x models {Ridge, ElasticNet, RandomForest, HistGB}. (16 configs)
                     All sets contain the last-season mean-attendance level anchor (attendance level shifted across the observed seasons).
  * Metric         : pooled MAE over the out-of-time test folds 2-3 (folds with >=54 training games); fold 1 is reported
                     but is trained on a single season (27 games) so it is not used for selection.
  * Rule           : take the lowest-MAE candidate; if an auditable LINEAR model is within 5% of it, prefer the linear model.
  * Extra variants (log target, no level anchor) were explored and are logged as EXPLORATORY; they are NOT eligible.
Random train/test splits are never used.
"""
import json
import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance  # noqa: F401  (documented alternative; custom version below)
from config import OUT, TAB, PROC, RANDOM_STATE, OFFICIAL_SEAT_COUNT, NEAR_CAPACITY_THRESHOLD, TEAM_KO
from modeling_lib import (ADV_CORE, GW_CORE, FEATURE_LABELS, FOLDS, load_dataset, opp_cols, backtest_baselines,
                          backtest_model, summarize, metrics, fit_predict, make_estimator)

rng = np.random.default_rng(RANDOM_STATE)
df = load_dataset()
OC = opp_cols(df)
FSETS = {"A": ADV_CORE, "A+opp": ADV_CORE + OC, "B": GW_CORE, "B+opp": GW_CORE + OC}
KINDS = ["ridge", "enet", "rf", "hgb"]
PS = "prior_season_mean_attendance"

# ------------------------------------------------------------------ 1. model selection log
log_rows, preds_store = [], {}
def record(name, feats, kind, log_target=False, eligible=True, note=""):
    p = backtest_model(df, feats, kind, log_target)
    s = summarize(p)
    preds_store[(name, kind, log_target)] = p
    log_rows.append(dict(feature_set=name, model=kind, log_target=log_target, eligible=eligible, note=note,
                         MAE_fold1_S43=s["S43"]["MAE"], MAE_fold2_S45=s["S45"]["MAE"], MAE_fold3_S47=s["S47"]["MAE"],
                         MAE_pooled_all=s["pooled_all"]["MAE"], MAE_pooled_folds2_3=s["pooled_folds2_3"]["MAE"],
                         RMSE_pooled=s["pooled_all"]["RMSE"], MAPE_pooled=s["pooled_all"]["MAPE"], R2_pooled=s["pooled_all"]["R2"]))
for name, feats in FSETS.items():
    for kind in KINDS:
        record(name, feats, kind)
for name, feats in FSETS.items():                                   # exploratory (not eligible)
    for kind in ["ridge", "enet"]:
        record(name, feats, kind, log_target=True, eligible=False, note="log-target (exploratory)")
    for kind in KINDS:
        record(name + " WITHOUT level anchor", [f for f in feats if f != PS], kind, eligible=False, note="no prior-season anchor (exploratory)")
sel_log = pd.DataFrame(log_rows)
sel_log.to_csv(TAB / "model_selection_log.csv", index=False)

def choose(stage_sets):
    el = sel_log[(sel_log.eligible) & (sel_log.feature_set.isin(stage_sets))].copy()
    best = el.loc[el.MAE_pooled_folds2_3.idxmin()]
    lin = el[el.model.isin(["ridge", "enet"])]
    lbest = lin.loc[lin.MAE_pooled_folds2_3.idxmin()]
    pick = lbest if lbest.MAE_pooled_folds2_3 <= 1.05 * best.MAE_pooled_folds2_3 else best
    return pick, best
pickA, bestA = choose(["A", "A+opp"])
pickB, bestB = choose(["B", "B+opp"])
print("MODEL A pick:", pickA.feature_set, pickA.model, round(pickA.MAE_pooled_folds2_3), "| best overall:", bestA.feature_set, bestA.model, round(bestA.MAE_pooled_folds2_3))
print("MODEL B pick:", pickB.feature_set, pickB.model, round(pickB.MAE_pooled_folds2_3), "| best overall:", bestB.feature_set, bestB.model, round(bestB.MAE_pooled_folds2_3))
SPEC = {"A": (pickA.feature_set, pickA.model), "B": (pickB.feature_set, pickB.model)}

# ------------------------------------------------------------------ 2. out-of-time predictions, intervals, levels
base = backtest_baselines(df)
oot = base.merge(df[["game_id", "game_date", "season", "opponent", "attendance", "near_capacity_flag"]], on="game_id")
for m in ["A", "B"]:
    fs, kind = SPEC[m]
    p = preds_store[(fs, kind, False)][["game_id", "pred"]].rename(columns={"pred": f"pred_{m}"})
    oot = oot.merge(p, on="game_id")
oot["resid_A"] = oot.y - oot.pred_A
oot["resid_B"] = oot.y - oot.pred_B

def fold_honest_interval(col):
    lo, hi, has = [], [], []
    order = ["S43", "S45", "S47"]
    for i, f in enumerate(order):
        te = oot[oot.fold == f]
        prev = oot[oot.fold.isin(order[:i])][f"resid_{col}"] if i > 0 else None
        if prev is None or len(prev) < 20:                      # fold 1 has no earlier residuals -> no interval
            lo += [np.nan] * len(te); hi += [np.nan] * len(te); continue
        q10, q90 = np.quantile(prev, [0.10, 0.90])
        lo += list(np.clip(te[f"pred_{col}"] + q10, 0, OFFICIAL_SEAT_COUNT)); hi += list(np.clip(te[f"pred_{col}"] + q90, 0, OFFICIAL_SEAT_COUNT))
    oot[f"lo80_{col}"] = lo; oot[f"hi80_{col}"] = hi
for m in ["A", "B"]:
    fold_honest_interval(m)
    ok = oot[f"lo80_{m}"].notna()
    cov = ((oot.y[ok] >= oot[f"lo80_{m}"][ok]) & (oot.y[ok] <= oot[f"hi80_{m}"][ok])).mean()
    print(f"Model {m}: fold-honest 80% interval coverage on folds 2-3 = {cov:.1%} (n={ok.sum()})")

# demand level thresholds: terciles of OBSERVED attendance in the training seasons of each fold (no test info)
def level_from(v, t1, t2):
    return np.where(v < t1, "LOW", np.where(v > t2, "HIGH", "MID"))
lv = []
for tr_s, te_s in FOLDS:
    tr = df[df.season_code.isin(tr_s)].attendance
    t1, t2 = np.quantile(tr, [1 / 3, 2 / 3])
    te = oot[oot.fold == te_s]
    lv.append(pd.DataFrame(dict(game_id=te.game_id, thr_low=t1, thr_high=t2,
                                actual_level=level_from(te.y.values, t1, t2),
                                level_A=level_from(te.pred_A.values, t1, t2), level_B=level_from(te.pred_B.values, t1, t2))))
oot = oot.merge(pd.concat(lv), on="game_id")
oot.to_csv(TAB / "backtest_predictions.csv", index=False)
ORD = {"LOW": 0, "MID": 1, "HIGH": 2}
def lvl_stats(col):
    a = oot.actual_level.map(ORD); b = oot[col].map(ORD)
    return dict(exact=float((a == b).mean()), within_one=float((abs(a - b) <= 1).mean()), severe_miss=float((abs(a - b) == 2).mean()))
level_stats = {"A": lvl_stats("level_A"), "B": lvl_stats("level_B")}

# ------------------------------------------------------------------ 3. headline comparison table
def row(name, col):
    d = oot[["fold", "y", col]].rename(columns={col: "pred"})
    s = summarize(d)
    return dict(MODEL=name, MAE=s["pooled_all"]["MAE"], RMSE=s["pooled_all"]["RMSE"], MAPE=s["pooled_all"]["MAPE"], R2=s["pooled_all"]["R2"],
                MAE_fold1_S43=s["S43"]["MAE"], MAE_fold2_S45=s["S45"]["MAE"], MAE_fold3_S47=s["S47"]["MAE"], MAE_folds2_3=s["pooled_folds2_3"]["MAE"])
comp = pd.DataFrame([
    row("Baseline 1 - training-period mean", "B1_train_mean"),
    row("Baseline 1b - previous-season mean (advance-plan naive)", "B1b_prior_season_mean"),
    row("Baseline 2 - last-5 home games mean", "B2_last5_home_mean"),
    row(f"MODEL A - Advance Planning ({SPEC['A'][0]} / {SPEC['A'][1]})", "pred_A"),
    row(f"MODEL B - Game-week Update ({SPEC['B'][0]} / {SPEC['B'][1]})", "pred_B")])
comp.to_csv(TAB / "model_comparison.csv", index=False)
print(comp.round(1).to_string())

# ------------------------------------------------------------------ 4. sell-out sensitivity
sens = []
for m in ["A", "B"]:
    fs, kind = SPEC[m]; feats = FSETS[fs]
    for tag, train_excl in [("train incl. near-capacity", False), ("train EXCL. near-capacity", True)]:
        pr = []
        for tr_s, te_s in FOLDS:
            tr = df[df.season_code.isin(tr_s)]
            if train_excl: tr = tr[tr.near_capacity_flag == 0]
            te = df[df.season_code == te_s]
            p, _ = fit_predict(kind, tr[feats], tr.attendance.values, te[feats])
            pr.append(pd.DataFrame(dict(game_id=te.game_id.values, y=te.attendance.values, pred=p, nc=te.near_capacity_flag.values)))
        pr = pd.concat(pr)
        for evalset, sub in [("all test games", pr), ("test games below near-capacity threshold", pr[pr.nc == 0])]:
            sens.append(dict(model=m, training=tag, evaluated_on=evalset, n=len(sub), MAE=float(np.abs(sub.y - sub.pred).mean()),
                             mean_error=float((sub.y - sub.pred).mean())))
sens = pd.DataFrame(sens); sens.to_csv(TAB / "sellout_sensitivity.csv", index=False)
print(sens.round(0).to_string())

# ------------------------------------------------------------------ 5. drift, residual cases
drift = []
for f, g in oot.groupby("fold"):
    for m in ["A", "B"]:
        drift.append(dict(test_season=f, model=m, MAE=float(np.abs(g[f"resid_{m}"]).mean()), bias_actual_minus_pred=float(g[f"resid_{m}"].mean()),
                          baseline_MAE_prior_season_mean=float(np.abs(g.y - g.B1b_prior_season_mean).mean())))
pd.DataFrame(drift).to_csv(TAB / "drift_by_season.csv", index=False)
cases = oot.assign(residual=oot.resid_B)[["game_id", "game_date", "season", "opponent", "y", "pred_B", "residual", "near_capacity_flag"]]
cases.sort_values("residual", ascending=False).head(5).assign(kind="ABOVE forecast").to_csv(TAB / "residual_cases_above.csv", index=False)
cases.sort_values("residual").head(5).assign(kind="BELOW forecast").to_csv(TAB / "residual_cases_below.csv", index=False)

# ------------------------------------------------------------------ 6. permutation importance (out-of-time) + direction
def groups_for(feats):
    g = {f: [f] for f in feats if f not in OC}
    if any(c in feats for c in OC): g["opponent identity"] = [c for c in OC if c in feats]
    return g
def oot_permutation_importance(feats, kind, n_rep=25):
    grp = groups_for(feats); acc = {k: [] for k in grp}
    for tr_s, te_s in FOLDS:
        tr = df[df.season_code.isin(tr_s)]; te = df[df.season_code == te_s].reset_index(drop=True)
        p, m = fit_predict(kind, tr[feats], tr.attendance.values, te[feats])
        base_mae = np.abs(te.attendance - p).mean()
        for k, cols in grp.items():
            inc = []
            for _ in range(n_rep):
                Xp = te[feats].copy(); idx = rng.permutation(len(te)); Xp[cols] = te[cols].values[idx]
                inc.append(np.abs(te.attendance - m.predict(Xp)).mean() - base_mae)
            acc[k].append(np.mean(inc))
    return pd.DataFrame(dict(feature=list(acc), mae_increase=[np.mean(v) for v in acc.values()],
                             folds_positive=[int(sum(x > 0 for x in v)) for v in acc.values()]))
def direction(feats, kind):
    """Partial-dependence contrast on the FINAL model: prediction with feature at its 75th pct (binary: 1) minus at 25th pct (binary: 0)."""
    _, m = fit_predict(kind, df[feats], df.attendance.values, df[feats])
    out = {}
    for f in feats:
        if f in OC: continue
        v = df[f]
        lo, hi = (0, 1) if set(v.dropna().unique()) <= {0, 1} else tuple(np.quantile(v.dropna(), [0.25, 0.75]))
        if lo == hi: out[f] = 0.0; continue
        a = df[feats].copy(); b = df[feats].copy(); a[f] = lo; b[f] = hi
        out[f] = float(m.predict(b).mean() - m.predict(a).mean())
    if any(c in feats for c in OC):
        means = {}
        for c in OC:
            X = df[feats].copy(); X[OC] = 0; X[c] = 1; means[c] = m.predict(X).mean()
        avg = np.mean(list(means.values()))
        out["opponent identity"] = float(np.mean([abs(v - avg) for v in means.values()]))
        for c, v in means.items(): out[c] = float(v - avg)
    return out
imp = {}
for m in ["A", "B"]:
    fs, kind = SPEC[m]; feats = FSETS[fs]
    pi = oot_permutation_importance(feats, kind)
    dr = direction(feats, kind)
    pi["direction_contrast_people"] = pi.feature.map(dr)
    pi["label"] = pi.feature.map(lambda f: FEATURE_LABELS.get(f, f))
    pi = pi.sort_values("mae_increase", ascending=False)
    pi.to_csv(TAB / f"feature_importance_model_{m}.csv", index=False)
    imp[m] = pi
    opp_dir = pd.Series({TEAM_KO.get(c.replace('opp_', ''), c): dr[c] for c in OC if c in dr}).sort_values(ascending=False)
    opp_dir.to_csv(TAB / f"opponent_effects_model_{m}.csv", header=["partial_dependence_vs_avg_opponent"])
    print(f"\nModel {m} importance (out-of-time permutation):\n", pi[["label", "mae_increase", "folds_positive", "direction_contrast_people"]].round(1).head(12).to_string())

# ------------------------------------------------------------------ 7. FINAL models on all 108 games + export for the HTML planner
final = {}
for m in ["A", "B"]:
    fs, kind = SPEC[m]; feats = FSETS[fs]
    _, model = fit_predict(kind, df[feats], df.attendance.values, df[feats])
    final[m] = (feats, kind, model)
res_all = {m: oot[f"resid_{m}"].values for m in ["A", "B"]}
q = {m: dict(q10=float(np.quantile(res_all[m], 0.10)), q90=float(np.quantile(res_all[m], 0.90))) for m in ["A", "B"]}
t1, t2 = [float(x) for x in np.quantile(df.attendance, [1 / 3, 2 / 3])]

def export_linear(model, feats):
    imp_, sc, est = model.named_steps["pre"].named_steps["imp"], model.named_steps["pre"].named_steps["sc"], model.named_steps["est"]
    return dict(type="linear", features=feats, median=list(map(float, imp_.statistics_)), mean=list(map(float, sc.mean_)),
                scale=list(map(float, sc.scale_)), coef=list(map(float, est.coef_)), intercept=float(est.intercept_))
def export_hgb(model, feats):
    imp_, est = model.named_steps["imp"], model.named_steps["est"]
    trees = []
    for it in est._predictors:
        nd = it[0].nodes
        trees.append(dict(f=nd["feature_idx"].astype(int).tolist(), t=nd["num_threshold"].astype(float).tolist(),
                          l=nd["left"].astype(int).tolist(), r=nd["right"].astype(int).tolist(),
                          v=nd["value"].astype(float).tolist(), leaf=nd["is_leaf"].astype(int).tolist()))
    return dict(type="hgb", features=feats, median=list(map(float, imp_.statistics_)), baseline=float(np.ravel(est._baseline_prediction)[0]), trees=trees)
def py_eval_hgb(exp, x):
    s = exp["baseline"]
    for t in exp["trees"]:
        i = 0
        while not t["leaf"][i]:
            i = t["l"][i] if x[t["f"][i]] <= t["t"][i] else t["r"][i]
        s += t["v"][i]
    return s
exports = {}
for m in ["A", "B"]:
    feats, kind, model = final[m]
    exports[m] = export_linear(model, feats) if kind in ("ridge", "enet") else export_hgb(model, feats) if kind == "hgb" else None
    assert exports[m] is not None, f"model {kind} cannot be exported to the HTML planner"
    # exactness check of the export vs sklearn on all 108 rows
    X = model.named_steps["imp"].transform(df[feats]) if kind in ("hgb", "rf") else None
    for i in range(len(df)):
        xr = df[feats].iloc[i].fillna(pd.Series(exports[m]["median"], index=feats)).values.astype(float)
        if exports[m]["type"] == "linear":
            e = exports[m]; py = e["intercept"] + sum(c * (v - mu) / sc for c, v, mu, sc in zip(e["coef"], xr, e["mean"], e["scale"]))
        else:
            py = py_eval_hgb(exports[m], xr)
        assert abs(py - model.predict(df[feats].iloc[[i]])[0]) < 1e-6, (m, i)
print(f"\nExport check: exported models reproduce sklearn predictions exactly ({len(df)}/{len(df)} rows, both models).")

# next-season opponent draw index table (uses ALL four observed seasons; same construct as training feature)
from build_dataset import build_odi, ODI_K
res_games = pd.read_csv(PROC / "league_games.csv", parse_dates=["date"], dtype={"start_time": str})
att_l = pd.read_csv(OUT.parent / "data" / "raw" / "kbl_league_home_attendance_raw.csv")
odi_tbl = build_odi(att_l, res_games)
odi_next = {a: float((g.ratio.sum() + ODI_K) / (len(g) + ODI_K)) for a, g in odi_tbl.groupby("away")}
month_prog = df.groupby("month_idx").season_progress.median().to_dict()
med = df[[c for c in set(FSETS["B+opp"]) if c in df.columns]].median().to_dict()
ranges = {c: [float(df[c].min()), float(df[c].max())] for c in ["pregame_KT_win_pct", "KT_last5_win_pct", "rolling_3_home_attendance", "temp_avg", "KT_streak", "days_since_last_game"] if c in df.columns}
planner = dict(models=exports, residual_q=q, level_thresholds=dict(low_below=t1, high_above=t2), odi_next_season=odi_next,
               month_progress={int(k): float(v) for k, v in month_prog.items()}, medians={k: float(v) for k, v in med.items()},
               ranges=ranges, opponents={c.replace("opp_", ""): TEAM_KO[c.replace("opp_", "")] for c in OC},
               labels=FEATURE_LABELS, seat_cap=OFFICIAL_SEAT_COUNT, spec={m: dict(feature_set=SPEC[m][0], model=SPEC[m][1]) for m in SPEC},
               oot_mae={m: float(np.abs(res_all[m]).mean()) for m in ["A", "B"]})
(OUT / "planner_model.json").write_text(json.dumps(planner, ensure_ascii=False))

# ------------------------------------------------------------------ 8. metrics json
def cov(m):
    ok = oot[f"lo80_{m}"].notna()
    return float(((oot.y[ok] >= oot[f"lo80_{m}"][ok]) & (oot.y[ok] <= oot[f"hi80_{m}"][ok])).mean()), int(ok.sum())
mA, mB = comp.iloc[3], comp.iloc[4]
gain = lambda a, b: float((a - b) / a * 100)
metrics_json = dict(
    selection_rule="pooled MAE on out-of-time folds 2-3; linear model preferred when within 5% of best",
    spec=planner["spec"], comparison=comp.round(3).to_dict(orient="records"),
    game_week_vs_advance=dict(MAE_pooled_all_gain_pct=gain(mA.MAE, mB.MAE), MAE_folds2_3_gain_pct=gain(mA.MAE_folds2_3, mB.MAE_folds2_3),
                              per_fold_gain_pct={f: gain(mA[c], mB[c]) for f, c in [("S43", "MAE_fold1_S43"), ("S45", "MAE_fold2_S45"), ("S47", "MAE_fold3_S47")]}),
    improvement_vs_best_baseline_pct=dict(A=gain(comp.iloc[:3].MAE.min(), mA.MAE), B=gain(comp.iloc[:3].MAE.min(), mB.MAE)),
    interval80=dict(A=dict(zip(["coverage", "n"], cov("A"))), B=dict(zip(["coverage", "n"], cov("B"))),
                    final_residual_quantiles=q, method="10th/90th percentile of out-of-time residuals; fold-honest coverage uses only earlier folds' residuals"),
    level_thresholds_final=dict(low_below=t1, high_above=t2), level_accuracy=level_stats,
    dataset=dict(n_games=int(len(df)), mean_att=float(df.attendance.mean()), median_att=float(df.attendance.median()),
                 near_capacity_games=int(df.near_capacity_flag.sum())),
)
(OUT / "model_metrics.json").write_text(json.dumps(metrics_json, ensure_ascii=False, indent=2))
print("\nlevel accuracy:", level_stats)
print(json.dumps({k: metrics_json[k] for k in ["game_week_vs_advance", "improvement_vs_best_baseline_pct"]}, indent=1))
