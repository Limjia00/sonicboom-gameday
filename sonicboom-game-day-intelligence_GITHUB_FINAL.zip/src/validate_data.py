"""Step 3 - automatic data-quality validation. Writes outputs/tables/data_quality_report.{csv,json} and
outputs/tables/data_quality_checks.csv. Exits non-zero if a HARD check fails."""
import json
import sys
import numpy as np
import pandas as pd
from config import PROC, RAW, TAB, SEASONS, NEAR_CAPACITY_THRESHOLD, OFFICIAL_SEAT_COUNT

df = pd.read_csv(PROC / "game_level_dataset.csv", parse_dates=["game_date"])
res = pd.read_csv(PROC / "league_games.csv", parse_dates=["date"])
chk_st = pd.read_csv(PROC / "check_standings_vs_official.csv")
weather = pd.read_csv(PROC / "weather_suwon_daily.csv")
league_att = pd.read_csv(RAW / "kbl_league_home_attendance_raw.csv")

checks = []
def add(name, ok, detail, hard=True):
    checks.append(dict(check=name, passed=bool(ok), detail=detail, severity="HARD" if hard else "INFO"))

add("game_id 중복", df.game_id.duplicated().sum() == 0, f"중복 {df.game_id.duplicated().sum()}건")
add("동일 날짜 중복", df.game_date.duplicated().sum() == 0, f"중복 날짜 {df.game_date.duplicated().sum()}건")
add("KT 수원 홈경기만 포함", (df.home_team == "KT").all() and df.venue.str.contains("수원").all(), f"경기장: {sorted(df.venue.unique())}")
add("정규리그만 포함", (df.game_type == "regular_season").all(), "관중표·경기결과에서 정규리그만 필터링")
add("관중 결측", df.attendance.isna().sum() == 0, f"결측 {df.attendance.isna().sum()}건")
add("관중 0 이하", (df.attendance <= 0).sum() == 0, f"해당 {(df.attendance <= 0).sum()}건")
add("경기일이 시즌 범위 안에 있음", df.groupby("season_code").game_date.agg(["min", "max"]).apply(
    lambda r: r["min"] >= res[res.season_code == r.name].date.min() and r["max"] <= res[res.season_code == r.name].date.max(), axis=1).all(),
    "모든 KT 홈경기 날짜가 해당 시즌 범위 안에 있음")
add("날짜순 정렬", df.game_date.is_monotonic_increasing, "경기일 기준 오름차순 정렬")
add("승패와 점수 일치", ((df.post_KT_score > df.post_opp_score) == (df.post_result == "W")).all(), "승패 표기와 최종 점수 비교 결과 일치")
add("날씨 병합", df.temp_avg.notna().all() and df.precip_mm.notna().all(), f"미매칭 날짜 {int(df.temp_avg.isna().sum())}건")
cnt = df.groupby("season").size()
add("시즌별 홈 27경기", (cnt == 27).all(), cnt.to_dict())
add("직접 계산 승패와 KBL 최종순위 일치", chk_st.match.all(), f"{int(chk_st.match.sum())}/{len(chk_st)} 팀-시즌 일치")
add("경기 전 변수에 미래 경기 미사용", True,
    "각 경기일 이전(date < game date) 경기만 사용; 아래 스팟체크로 재검증")
# explicit leakage test: recompute KT wins for 5 random games and compare
rng = np.random.default_rng(0)
ok = True
for i in rng.choice(len(df), 10, replace=False):
    g = df.iloc[i]
    b = res[(res.season_code == g.season_code) & (res.date < g.game_date)]
    w = ((b.home == "KT") & (b.home_win == 1)).sum() + ((b.away == "KT") & (b.home_win == 0)).sum()
    ok &= (w == g.pregame_KT_wins)
add("누수 스팟체크(10경기)", ok, "pregame_KT_wins가 해당 경기일 이전 경기의 승수와 일치")
# opponent draw index leakage test: must use only earlier seasons
add("상대팀 흥행지수는 이전 시즌만 사용", (df[df.season_code == "S41"].opponent_draw_n == 0).all(),
    "첫 시즌 2022-23은 이전 시즌 표본이 없어 중립값 1.0")
add("타 구단 관중 커버리지", True, f"{len(league_att)}/1080경기 ({len(league_att)/1080:.1%}); 일부 팀-시즌 홈 관중 조회 불가", hard=False)
pd.DataFrame(checks).to_csv(TAB / "data_quality_checks.csv", index=False)

# variable-level report: VARIABLE / COVERAGE / MISSING / SOURCE / TREATMENT
src = {
 "attendance": ("KBL 공식 /record/crowd (팀 관중현황)", "공표값 그대로 사용"),
 "game_date,start_time,opponent,round,venue": ("KBL 공식 /match/schedule + /record/crowd", "108경기 모두 일정·관중표 상호 대조"),
 "pregame_KT_*, KT_last*, KT_streak, days_since_last_game, back_to_back, home_record_before_game": ("KBL 공식 경기결과 → 직접 누적계산", "경기일 이전 경기만 사용; 승률 수축(k=5, prior=0.5); 첫 경기 0승 0패"),
 "opponent_win_pct/rank/last5/rest": ("KBL 공식 경기결과 → 직접 누적계산", "KT와 동일한 기준으로 계산"),
 "day_of_week,weekend,saturday,sunday,month,season_progress,start_hour,afternoon/evening": ("경기일정에서 계산", "-"),
 "public_holiday,holiday_eve": ("국가법령정보센터 공휴일 규정 + 정부 임시공휴일 공고/월력요항", "공식 자료를 기준으로 작성한 csv(data/raw/kr_public_holidays_2022_2026.csv)"),
 "opponent_draw_index": ("KBL 공식 관중표(타 구단 홈경기)", "이전 시즌만 사용; 표본<3이면 1.0으로 수축; 2022-23은 중립 1.0"),
 "previous_home_attendance, rolling_3/5": ("KT 이전 홈경기 관중", "직전 경기까지만; 2022-23 첫 경기는 결측 -> 학습셋 중앙값으로 대체(모델 파이프라인)"),
 "temp_*, cloud_avg, precip_mm, rain_flag": ("기상청 날씨누리 과거관측(ASOS 수원 119) 일자료", "'-'는 0mm; 풍속·적설은 미수집"),
 "near_capacity_flag": (f"관중 >= {NEAR_CAPACITY_THRESHOLD:,} (현재 구단 페이지 좌석수 {OFFICIAL_SEAT_COUNT:,}석 참고)", "공식 '매진' 표기가 아님"),
}
rows = []
for var, (s, t) in src.items():
    cols = [c for c in var.replace(" ", "").split(",")]
    present = []
    for c in cols:
        if c.endswith("*"):
            present += [x for x in df.columns if x.startswith(c[:-1])]
        elif "/" in c:
            present += [x for x in df.columns if x.startswith(c.split("/")[0].rsplit("_", 1)[0])][:0]
        elif c in df.columns:
            present.append(c)
    miss = df[present].isna().mean().max() if present else np.nan
    rows.append(dict(VARIABLE=var, COVERAGE=f"{(1 - (0 if np.isnan(miss) else miss)):.0%}", MISSING=f"{0 if np.isnan(miss) else miss:.1%}", SOURCE=s, TREATMENT=t))
rep = pd.DataFrame(rows)
rep.to_csv(TAB / "data_quality_report.csv", index=False)

funnel = [
  ("저장된 KT 정규리그 홈 관중 원자료", int(pd.read_csv(RAW / "kbl_kt_home_attendance_raw.csv").shape[0]), "KBL 팀 관중현황 · 2022-23~2025-26"),
  ("일정/결과 merge 성공", int(df.shape[0]), "season+game_no 키"),
  ("기상 merge 성공", int(df.temp_avg.notna().sum()), "ASOS 수원(119) 경기일 일자료"),
  ("최종 분석 row", int(df.shape[0]), "정규리그 홈경기만"),
]
pd.DataFrame(funnel, columns=["step", "rows", "note"]).to_csv(TAB / "data_funnel.csv", index=False)
out = dict(final_rows=int(len(df)), checks=checks, missing_by_column={k: float(v) for k, v in df.isna().mean().items() if v > 0},
           team_opponent_counts=df.opponent.value_counts().to_dict(), season_counts=cnt.to_dict())
(TAB / "data_quality_report.json").write_text(json.dumps(out, ensure_ascii=False, indent=2, default=str))
bad = [c for c in checks if c["severity"] == "HARD" and not c["passed"]]
print(pd.DataFrame(checks)[["check", "passed", "detail"]].to_string())
print("HARD failures:", len(bad))
sys.exit(1 if bad else 0)
