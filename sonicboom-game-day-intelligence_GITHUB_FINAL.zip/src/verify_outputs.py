"""Step 8 - automatic consistency checks between the Python outputs and what index.html shows.
Fails loudly (AssertionError) if any number in the page disagrees with the number recomputed from the processed data."""
import json, re, sys, asyncio, shutil
import numpy as np
import pandas as pd
from config import ROOT, PROC, TAB, OUT, NEAR_CAPACITY_THRESHOLD
from modeling_lib import load_dataset, fit_predict, ADV_CORE, GW_CORE, opp_cols

html = (ROOT / "index.html").read_text(encoding="utf-8")
m = re.search(r"const DATA=(\{.*?\});\s*</script>", html, re.S)
D = json.loads(m.group(1).replace("<\\/", "</"))
ds = pd.read_csv(PROC / "game_level_dataset.csv")
bt = pd.read_csv(TAB / "backtest_predictions.csv")
ok = []
def check(name, a, b, tol=1e-6):
    assert abs(a - b) <= tol, f"MISMATCH {name}: html={a} python={b}"
    ok.append(name)

# 1. dataset-level KPIs
check("n_games", D["metrics"]["dataset"]["n_games"], len(ds))
check("avg_attendance", D["metrics"]["dataset"]["mean_att"], ds.attendance.mean())
check("near_capacity", D["metrics"]["dataset"]["near_capacity_games"], int((ds.attendance >= NEAR_CAPACITY_THRESHOLD).sum()))
check("payload games rows", len(D["eda"]["games"]), len(ds))
for g in D["eda"]["games"]:
    assert int(ds.loc[ds.game_id == g["game_id"], "attendance"].iloc[0]) == g["attendance"]
ok.append("per-game attendance identical (108)")
# 2. model metrics recomputed from raw predictions
for i, col in enumerate(["B1_train_mean", "B1b_prior_season_mean", "B2_last5_home_mean", "pred_A", "pred_B"]):
    mae = (bt.y - bt[col]).abs().mean(); rmse = np.sqrt(((bt.y - bt[col]) ** 2).mean()); mape = ((bt.y - bt[col]).abs() / bt.y).mean() * 100
    check(f"MAE[{col}]", D["comparison"][i]["MAE"], mae, 1e-3); check(f"RMSE[{col}]", D["comparison"][i]["RMSE"], rmse, 1e-3); check(f"MAPE[{col}]", D["comparison"][i]["MAPE"], mape, 1e-3)
# 3. no run-time fetches / external assets
assert not re.search(r"\b(fetch|XMLHttpRequest)\s*\(", html.split("const DATA=")[0] + html.split("</script>", 1)[1]), "network call found"
assert not re.search(r"<(script|link|img)[^>]+(src|href)=[\"']https?://", html), "external asset referenced"
ok.append("no external assets / no fetch")
# 4. leakage guard on features actually used
banned = ("post_", "attendance", "final")
for mkey in "AB":
    for f in D["planner"]["models"][mkey]["features"]:
        assert not f.startswith("post_") and f not in ("attendance", "near_capacity_flag"), f
        assert f in ("prior_season_mean_attendance", "rolling_3_home_attendance") or "attendance" not in f, f
ok.append("no post-game / same-game attendance features")

# 5. JS planner == sklearn (headless browser)
async def js_vs_sklearn():
    from playwright.async_api import async_playwright
    df = load_dataset(); OC = opp_cols(df); P = D["planner"]
    async with async_playwright() as p:
        try:
            b = await p.chromium.launch()
        except Exception as e:
            system_chromium = shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome") or shutil.which("google-chrome-stable")
            if not system_chromium:
                raise e
            b = await p.chromium.launch(executable_path=system_chromium, args=["--no-sandbox"])
        pg = await b.new_page(viewport={"width": 1280, "height": 900}); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("console", lambda m_: errs.append(m_.text) if m_.type == "error" else None)
        try:
            await pg.goto("file://" + str(ROOT / "index.html")); await pg.wait_for_timeout(500)
        except Exception as e:
            if "ERR_BLOCKED_BY_ADMINISTRATOR" not in str(e):
                raise
            await pg.close()
            pg = await b.new_page(viewport={"width": 1280, "height": 900})
            errs = []
            pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("console", lambda m_: errs.append(m_.text) if m_.type == "error" else None)
            await pg.set_content(html, wait_until="load"); await pg.wait_for_timeout(500)
        # KPI text vs python
        kpi = await pg.inner_text("#kpis")
        assert f"{len(ds)}" in kpi and f"{int(round(ds.attendance.mean())):,}" in kpi and f"{int(round((bt.y - bt.pred_B).abs().mean())):,}" in kpi, kpi
        ok.append("hero KPIs on screen match python")
        scen = [("A", "KCC", "saturday", 2, False, {}), ("A", "SN", "weekday", 0, True, {}),
                ("B", "SK", "sunday", 4, False, dict(l5=0.6, wp=.55, kr=3, orr=6, ow=.45, st=2, r3=2600, tp=3, rain=True)),
                ("B", "GS", "weekday", 5, False, dict(l5=0.2, wp=.35, kr=9, orr=9, ow=.3, st=-3, r3=1500, tp=8, rain=False))]
        for mode, opp, day, month, eve, gw in scen:
            await pg.click(f'#pMode button[data-m="{mode}"]'); await pg.select_option("#pOpp", opp); await pg.select_option("#pMonth", str(month))
            await pg.click(f'#pDay button[data-d="{day}"]'); await pg.set_checked("#pEve", eve)
            if mode == "B":
                for k, v in {"pL5": gw["l5"] * 100, "pWp": gw["wp"] * 100, "pKr": gw["kr"], "pOr": gw["orr"], "pOw": gw["ow"] * 100, "pSt": gw["st"], "pR3": gw["r3"], "pTp": gw["tp"]}.items():
                    await pg.eval_on_selector("#" + k, "(e,v)=>{e.value=v;e.dispatchEvent(new Event('input'))}", v)
                await pg.set_checked("#pRain", gw["rain"])
            shown = await pg.inner_text("#oF"); js_pred = int(shown.replace(",", "").replace("명", ""))
            # sklearn side
            feats = P["models"][mode]["features"]; med = P["medians"]
            row = {f: med.get(f, 0.0) for f in feats}
            row.update(saturday=float(day == "saturday"), sunday=float(day == "sunday"), weekday_holiday=float(day == "weekday_holiday"), holiday_eve=float(eve),
                       month_idx=float(month), season_progress=P["month_progress"][str(month)], opponent_draw_index=P["odi_next_season"][opp],
                       prior_season_mean_attendance=D["priorMean"])
            if mode == "B":
                row.update(pregame_KT_win_pct=gw["wp"], pregame_KT_rank=gw["kr"], KT_last5_win_pct=gw["l5"], KT_streak=gw["st"], opponent_win_pct_before_game=gw["ow"],
                           opponent_rank_before_game=gw["orr"], rolling_3_home_attendance=gw["r3"], rain_flag=float(gw["rain"]), temp_avg=gw["tp"])
                for c in OC: row[c] = float(c == "opp_" + opp)
            fs = "A" if mode == "A" else "B+opp"
            base_feats = ADV_CORE if mode == "A" else GW_CORE + OC
            pred, _ = fit_predict("ridge" if mode == "A" else "enet", df[base_feats], df.attendance.values, pd.DataFrame([row])[base_feats])
            assert abs(js_pred - max(0, pred[0])) <= 1, (mode, opp, day, js_pred, pred[0])
        ok.append(f"JS planner equals sklearn on {len(scen)} scenarios")
        assert not errs, errs
        await b.close()
asyncio.run(js_vs_sklearn())
print("VERIFIED:", *ok, sep="\n  - ")
